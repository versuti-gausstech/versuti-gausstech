var apiKey = "47173734";

var sessionId = "2_MX40NzE3MzczNH5-MTYyMDE2MzMyOTAwNn5uODNwQ0JjaXU5eklWY0xOZzZDb1pCUGF-UH4";

// token: moderator
var token_biomedico = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9NTMyMzI1ZjljNzg3YzRiZTEyZDk0MjMxZTQ0ZjYxZGI0ZDA1Njk4NjpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXlNREUyTXpNeU9UQXdObjV1T0ROd1EwSmphWFU1ZWtsV1kweE9aelpEYjFwQ1VHRi1VSDQmY3JlYXRlX3RpbWU9MTYyMDE2MzM1NyZub25jZT0wLjgzOTQwMTUxNzM4Nzk5MzQmcm9sZT1tb2RlcmF0b3ImZXhwaXJlX3RpbWU9MTYyMjc1NTM1NiZjb25uZWN0aW9uX2RhdGE9YmlvbWVkaWNvJmluaXRpYWxfbGF5b3V0X2NsYXNzX2xpc3Q9";
//var token_biomedico = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9OGIxZTQ4N2ZlOWQzZjg4MGM3MmU4YmQ4MDQ2M2UwMzM0YjE4OWIwMjpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXlNREUxTnpnNE1qZ3dNbjVFVjNCUmJEVnVaRVEzYzIxdmVYaFhNbWhRWlZsSmVteC1mZyZjcmVhdGVfdGltZT0xNjIwMTU5MTAwJm5vbmNlPTAuNTAzNTM0NDkwNjYzNTM3NyZyb2xlPW1vZGVyYXRvciZleHBpcmVfdGltZT0xNjIyNzUxMDk5JmNvbm5lY3Rpb25fZGF0YT1iaW9tZWRpY28maW5pdGlhbF9sYXlvdXRfY2xhc3NfbGlzdD0=";

// identificador da estacao do gauss command
var machineId = "Gauss Command";

var enfermeira1_connection = "";
var enfermeira2_connection = "";
var enfermeira3_connection = "";

var subscriber_enf1 = "";
var subscriber_enf2 = "";
var subscriber_enf3 = "";

var machineId_1  = "";
var machineId_2  = "";
var machineId_3  = "";


// falta implementar:
// via rest-api api.gausstech.io/rest-api/api/ordem.php?estacao_id=X
// estacao_id eh o id da estacao onde o biomedico esta assigned

console.log("Plataforma Gauss Command - modulo command.comm - v1.8 - mai/05/2021");

document.getElementById("botoes_som").style.visibility = "hidden";
document.getElementById("exitSession").style.visibility = "hidden";


function pacienteOn(machineId){
		console.log("Falando com o paciente..");
}

function pacienteOff(machineId){
		console.log("Nao falando com o paciente.");

}

function enfermagemOn(machineId){
		console.log("Falando com a enfermagem..");
}

function enfermagemOff(machineId){
		console.log("Nao falando com a enfermagem.");

}

var button = document.getElementById("startSession");
button.addEventListener("click", function(event){
  event.preventDefault();
  document.getElementById("botoes_som").style.visibility = "visible";
  document.getElementById("startSession").style.display = "none";
  document.getElementById("exitSession").style.visibility = "visible";
  initializeSession();
});

var btnSair = document.getElementById("exitSession");
btnSair.addEventListener("click", function(event){
  event.preventDefault();
  console.log("Saindo da sessao...");
  window.location.reload(false);
});


// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    console.log("Stream criado na sessao (id) : " + event.stream.id);
    console.log("Nome do stream: " + event.stream.connection.data);


    // testa o nome do stream pra append no div correto
    if(event.stream.connection.data == "enfermeira-1"){
        subscriber_enf1 = session.subscribe(event.stream, 'subscriber1', {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        style: {nameDisplayMode: "on"},
        showControls: true
      }, handleError);
      machineId_1 = event.stream.name;
      document.getElementById('label_m1').innerHTML = machineId_1;
      enfermeira1_connection = event.stream.connection;
    }
    if(event.stream.connection.data == "enfermeira-2"){
        subscriber_enf2 = session.subscribe(event.stream, 'subscriber2',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      machineId_2 = event.stream.name;
      document.getElementById('label_m2').innerHTML = machineId_2;
      enfermeira2_connection = event.stream.connection;
    }
    if(event.stream.connection.data == "enfermeira-3"){
      subscriber_enf3 = session.subscribe(event.stream, 'subscriber3',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      machineId_3 = event.stream.name;
      document.getElementById('label_m3').innerHTML = machineId_3;
      enfermeira3_connection = event.stream.connection;
    }
  });

  // listener para quando um stream eh destruido
  session.on('streamDestroyed', function(event) {
    console.log("Stream destruido (id) - " + event.stream.id);
    console.log("Nome do stream: "+ event.stream.connection.data);
    stream_name = event.stream.connection.data;

    // testa o nome do stream pra append no div correto
    if(stream_name == "enfermeira-1"){
        document.getElementById('label_m1').innerHTML = 'MRI-1';
        document.getElementById('history1').innerHTML = '';
    }
    if(stream_name == "enfermeira-2"){
        document.getElementById('label_m2').innerHTML = 'MRI-2';
        document.getElementById('history2').innerHTML = '';
    }
    if(stream_name == "enfermeira-3"){
        document.getElementById('label_m3').innerHTML = 'MRI-3';
        document.getElementById('history3').innerHTML = '';
    }
  });

  // Cria um publisher
  var publisherProperties = {
    insertMode: 'append',
    width: 100,
    height: 75,
    style: {nameDisplayMode: "on"},
    subscribeToAudio:true,
    showControls: true,
    videoSource: null
  };

  var publisher = OT.initPublisher("publisher", publisherProperties, handleError);
  console.log("Publisher inicializado ..");
  // Connect to the session
  session.connect(token_biomedico, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
      //publisher.stream.name = "teste";
      console.log("Publisher publicado! ");
    }
  });

  //----------------------------------------------------------------------------
  // tratamento do chat-1
  //----------------------------------------------------------------------------
  var msgHistory = document.querySelector('#history1');

  // trata a chegada de um sinal
  session.on("signal", function(event) {
      console.log("Sinal recebido da conexao (ID): " + event.from.id + " Mensagem: " + event.data);
      if(event.from.id == enfermeira1_connection.connectionId){
        //msgHistory = document.querySelector('#history1');
        msgHistory = document.getElementById("history1");
        enfermeira_connection = enfermeira1_connection;
        machineId = machineId_1;
      }
      if(event.from.id == enfermeira2_connection.connectionId){
        msgHistory = document.querySelector('#history2');
        enfermeira_connection = enfermeira2_connection;
        machineId = machineId_2;
      }
      if(event.from.id == enfermeira3_connection.connectionId){
        msgHistory = document.querySelector('#history3');
        enfermeira_connection = enfermeira3_connection;
        machineId = machineId_3;
      }

      // formata a mensagem que sera incluida no msgHistory
      var msg = document.createElement('p');
      msg.textContent = machineId + " : " + event.data;
      msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';
      msgHistory.appendChild(msg);
      msg.scrollIntoView();
  });

  var button = document.getElementById("muteall");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
          session.signal({
            to: enfermeira1_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
                msgHistory = document.querySelector('#history1');
                var msg = document.createElement('p');
          			msg.className = 'theirs';
          			msg.textContent = "--- ENFERMAGEM NÃO OUVINDO ---";
                msgHistory.appendChild(msg);
          			msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf2.id != null){
          session.signal({
            to: enfermeira2_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history2');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf3.id != null){
          session.signal({
            to: enfermeira3_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history3');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM NÃO OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }
  });


  var button = document.getElementById("broadcast");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
          session.signal({
            to: enfermeira1_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history1');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf2.id != null){
          session.signal({
            to: enfermeira2_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history2');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf3.id != null){
          session.signal({
            to: enfermeira3_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history3');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }
  });

  // inicializa os input texts de cada maquina
  mensagem1 = document.querySelector('#msgTxt1');
  mensagem2 = document.querySelector('#msgTxt2');
  mensagem3 = document.querySelector('#msgTxt3');

  mensagem1.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        txtMensagem = mensagem1.value ;
        msgHistory = document.querySelector('#history1');

        var msg = document.createElement('p');
        msg.textContent = machineId + " : " + txtMensagem;
        msg.className = 'mine';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
        session.signal({
          to: enfermeira1_connection,
          type: 'msg',
          data: txtMensagem
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            mensagem1.value = '';
          }
        });
      }
  });

  mensagem2.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        txtMensagem = mensagem2.value ;
        msgHistory = document.querySelector('#history2');

        var msg = document.createElement('p');
        msg.textContent = machineId + " : " + txtMensagem;
        msg.className = 'mine';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
        session.signal({
          to: enfermeira2_connection,
          type: 'msg',
          data: txtMensagem
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            mensagem2.value = '';
          }
        });
      }
  });

  mensagem3.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        txtMensagem = mensagem3.value ;
        msgHistory = document.querySelector('#history3');

        var msg = document.createElement('p');
        msg.textContent = machineId + " : " + txtMensagem;
        msg.className = 'mine';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
        session.signal({
          to: enfermeira3_connection,
          type: 'msg',
          data: txtMensagem
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            mensagem3.value = '';
          }
        });
      }
  });

  // labels para os botoes de chat
  var btnCommandIC = "injetar constraste";
  var btnCommandPP = "posicionar paciente";

  // listeners dos botoes com mensagem padrao
  // --- INJETAR CONTRASTE
  var button = document.getElementById("ic1");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history1');
    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: btnCommandIC
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandIC;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

  // --- POSICIONAR PACIENTE
  var button = document.getElementById("pp1");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history1');
    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: btnCommandPP
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandPP;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

	// --- MANDAR AUDIO PARA HOST-1
	var button = document.getElementById("fe");
	button.addEventListener("mousedown", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "ouvir"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- ENFERMAGEM OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
		}
	});

	// --- MUTAR AUDIO PARA HOST-1
	button.addEventListener("mouseup", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "nao-ouvir"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- ENFERMAGEM NÃO OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
			}
	});


	var button = document.getElementById("fp");
	button.addEventListener("mousedown", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "ouvir-paciente"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- PACIENTE OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
		}
	});

	// --- MUTAR AUDIO PARA HOST-1
	button.addEventListener("mouseup", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "nao-ouvir-paciente"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- PACIENTE NÃO OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
			}
	});

  var msgTxt = document.querySelector('#msgTxt2');
  var button = document.getElementById("ic2");

  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history2');
    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: btnCommandIC
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandIC;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp2");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history2');
    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: btnCommandPP
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandPP;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });



  var msgTxt = document.querySelector('#msgTxt3');
  var button = document.getElementById("ic3");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history3');
    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: btnCommandIC
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandIC;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp3");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history3');
    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: btnCommandPP
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandPP;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });


}
