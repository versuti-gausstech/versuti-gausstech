// replace these values with those generated in your TokBox Account
var apiKey = "47173734";
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";
var token = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9MmMwODUzZWUyODU5NjVmNmQ2NWY3OGExNDJhMTVhN2FhZTE0ODc2YjpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzgxODkyNyZub25jZT0wLjc4Nzk0MDA1MzQxNDgzNTUmcm9sZT1tb2RlcmF0b3ImZXhwaXJlX3RpbWU9MTYyMDQxMDkyNyZjb25uZWN0aW9uX2RhdGE9YmlvbWVkaWNvJmluaXRpYWxfbGF5b3V0X2NsYXNzX2xpc3Q9";

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

// Cycling through microphone inputs
var audioInputs;
let currentIndex = 0;
lstAudioCC = document.getElementById("audio-cc");
lstAudioPac = document.getElementById("audio-pac");
var alldevices = navigator.mediaDevices.enumerateDevices();

disable();
OT.getDevices((err, devices) => {
  audioInputs = devices.filter((device) => device.kind === 'audioInput');
  // audioInput = microfones
  console.log(alldevices);
  audioInputs.forEach((device, i) => {
    console.log(device.label + "|" + device.kind);
    var opt = document.createElement("option");
    lstAudioCC.options.add(opt);
    opt.text = device.label;
    opt.value = device.deviceId;

    var opt = document.createElement("option");
    lstAudioPac.options.add(opt);
    opt.text = device.label;
    opt.value = device.deviceId;
  });
});

function disable() {
  document.getElementById("audio-cc").disabled=true;
  document.getElementById("audio-pac").disabled=true;
  document.getElementById("salvar").disabled=true;
}
function enable() {
  document.getElementById("audio-cc").disabled=false;
  document.getElementById("audio-pac").disabled=false;
  document.getElementById("salvar").disabled=false;
}

function salvarAudio(){
  document.cookie = "audio_cc=" + lstAudioCC.value ;
  document.cookie = "audio_pac=" + lstAudioPac.value;
  disable();
  console.log("Audio salvo.");
}
