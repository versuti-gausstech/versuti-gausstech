//sempre constante
var apiKey = "47173734";

// indentifica a sala que contem o biomedico e as 3 maquinas
// relayed session
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";

// variavel que pega a conexao do biomedico do gauss command
var biomedico_connection;
var command_center_user = "";
var token_enfermagem = "";

var username = readCookie('username');

token_enfermagem = readCookie('token');
var marca = readCookie('marca');
var modelo = readCookie('modelo');
var localizacao = readCookie('localizacao');

var machineId = modelo + " " + marca + ' @ ' + localizacao;

// (optional) add server code here
initializeSession();

// pega os cookies gerados na sessao para obter o usuario logado
function readCookie(name) {
	var cookiename = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++)
	{
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(cookiename) == 0) return c.substring(cookiename.length,c.length);
	}
	return null;
}

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

var subscriber = "";
function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

	OT.getDevices((err, devices) => {
			console.log(devices);
	});

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    console.log("Novo stream criado na sessao - ID : " +event.stream.id);
    console.log("Nome do stream: " + event.stream.connection.data);
		command_center_user = event.stream.connection.data;
    if(event.stream.connection.data == "biomedico"){
      subscriber = session.subscribe(event.stream, 'subscriber', {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      biomedico_connection = event.stream.connection;

      return event.stream.connection.data;
   }
  });

  // Create a publisher
  var publisher = OT.initPublisher('publisher', {
    insertMode: 'append',
    width: 100,
    height: 75,
    style: {nameDisplayMode: "on"},
    subscribeToAudio:true,
    showControls: true,
		name: machineId,
    videoSource: null
  }, handleError);



	console.log("Publisher criado e inicializado...");
  // Connect to the session
  session.connect(token_enfermagem, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
			console.log("Publisher publicado!");
    }
  });

  // Receive a message and append it to the history
  var msgHistory = document.querySelector('#history');
  var onHistoryScreen = false;
  session.on("signal", function(event) {
      console.log("Sinal recebido da conexao (ID): " + event.from.id + " | Mensagem: " + event.data);
      if(event.from.id == biomedico_connection.connectionId){
        onHistoryScreen = true;
        if(event.data == "nao-ouvir"){
            subscriber.setAudioVolume(0);
            onHistoryScreen = false;
        }
        if(event.data == "ouvir"){
            subscriber.setAudioVolume(100);
            onHistoryScreen = false;
        }
				if(onHistoryScreen){
		        msgHistory = document.querySelector('#history');
		        var msg = document.createElement('p');
		        msg.textContent = command_center_user + " : " + event.data;
		        msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';
		        msgHistory.appendChild(msg);
		        msg.scrollIntoView();
				}
      }

  });



// Text chat
var form = document.querySelector('form');
var msgTxt = document.querySelector('#msgTxt');

msgTxt.addEventListener('keypress', function (e) {
		if (e.key === 'Enter') {
			e.preventDefault();
			txtMensagem = msgTxt.value ;
			msgHistory = document.querySelector('#history');

			var msg = document.createElement('p');
			msg.textContent = machineId + " : " + txtMensagem;
			msg.className = 'mine';
			msgHistory.appendChild(msg);
			msg.scrollIntoView();
			console.log("Mensagem de chat enviada: " + txtMensagem);
			session.signal({
				type: 'msg',
				data: txtMensagem
			}, function signalCallback(error) {
				if (error) {
					console.error('Error sending signal:', error.name, error.message);
				} else {
					msgTxt.value = '';
				}
			});
		}
});

// listeners dos botoes com mensagem padrao
// --- INJETAR CONTRASTE
var button = document.getElementById("ic");
button.addEventListener("click", function(event){
  event.preventDefault();
	var btnCommand = "injetar constraste";
  session.signal({
    type: 'msg',
    data: btnCommand
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
			var msg = document.createElement('p');
			msg.textContent = machineId + " : " + btnCommand;
			msg.className = 'mine';
			msgHistory.appendChild(msg);
			msg.scrollIntoView();
      msgTxt.value = '';
    }
  });
});

// --- INJETAR CONTRASTE
var button = document.getElementById("pp");
button.addEventListener("click", function(event){
  event.preventDefault();
	var btnCommand = "posicionar paciente";
  session.signal({
    type: 'msg',
    data: btnCommand
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
			var msg = document.createElement('p');
			msg.textContent = machineId + " : " + btnCommand;
			msg.className = 'mine';
			msgHistory.appendChild(msg);
			msg.scrollIntoView();

      msgTxt.value = '';
    }
  });
});
}
