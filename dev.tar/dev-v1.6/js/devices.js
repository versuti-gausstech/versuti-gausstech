// replace these values with those generated in your TokBox Account
var apiKey = "47173734";
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";
var token = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9MmMwODUzZWUyODU5NjVmNmQ2NWY3OGExNDJhMTVhN2FhZTE0ODc2YjpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzgxODkyNyZub25jZT0wLjc4Nzk0MDA1MzQxNDgzNTUmcm9sZT1tb2RlcmF0b3ImZXhwaXJlX3RpbWU9MTYyMDQxMDkyNyZjb25uZWN0aW9uX2RhdGE9YmlvbWVkaWNvJmluaXRpYWxfbGF5b3V0X2NsYXNzX2xpc3Q9";

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

// (optional) add server code here


initializeSession();

function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    session.subscribe(event.stream, 'subscriber', {
      insertMode: 'append',
      width: '20%',
      height: '20%'
    }, handleError);
  });

  // Create a publisher
  var publisher = OT.initPublisher('publisher', {
    insertMode: 'append',
    width: '20%',
    height: '20%'
  }, handleError);


  // Cycling through microphone inputs
  var audioInputs;
  let currentIndex = 0;
  OT.getDevices((err, devices) => {
    console.log(devices);
    audioInputs = devices.filter((device) => device.kind === 'audioInput');
    // Find the right starting index for cycleMicrophone
    audioInputs.forEach((device, idx) => {
      console.log(device);
    });
    console.log("Trocando o device..");
    publisher.setAudioSource(audioInputs[2].deviceId);
    console.log(publisher.getAudioSource());
  });
  // Connect to the session
  session.connect(token, function(error) {
    // If the connection is successful, initialize a publisher and publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
    }
  });
}
