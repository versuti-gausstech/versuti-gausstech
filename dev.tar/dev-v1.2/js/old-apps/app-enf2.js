// replace these values with those generated in your TokBox Account
var apiKey = "47173734";
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";
var token_enfermagem_2 = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9ZWIyYjdkODdjMDA5ZGU0ZmIwMzRlYjJiY2RhZDg1ZjcwMjMzNjcwZTpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzY0MTg4NCZyb2xlPXB1Ymxpc2hlciZub25jZT0xNjE3NjQxODg0Ljk2NjU5NTEwOTcwMDgmY29ubmVjdGlvbl9kYXRhPWVuZmVybWVpcmEtMiZpbml0aWFsX2xheW91dF9jbGFzc19saXN0PQ==";

var machineId = "Philips Unidade 3";
var biomedico_connection;
// (optional) add server code here
initializeSession();

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  data = session.on('streamCreated', function(event) {
    if(event.stream.connection.data == "biomedico"){
      session.subscribe(event.stream, 'subscriber', {
        insertMode: 'append',
        width: 200,
        height: 150,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      biomedico_connection = event.stream.connection;
      return event.stream.connection.data;
   }
  });

  // Create a publisher
  var publisher = OT.initPublisher('publisher', {
    insertMode: 'append',
    width: 200,
    height: 150,
    name: machineId,
    style: {nameDisplayMode: "on"},
    subscribeToAudio:true,
    subscribeToVideo:false,
    showControls: true
  }, handleError);

  // Connect to the session
  session.connect(token_enfermagem_2, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
    }
  });

  // Receive a message and append it to the history
  var msgHistory = document.querySelector('#history');

  session.on("signal", function(event) {
      console.log("Signal sent from connection " + event.from.id);
      if(event.from.id == biomedico_connection.connectionId){
        msgHistory = document.querySelector('#history');
        var msg = document.createElement('p');
        msg.textContent = event.data;
        msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
      }

  });



// Text chat
var form = document.querySelector('form');
var msgTxt = document.querySelector('#msgTxt');

// Send a signal once the user enters data in the form
form.addEventListener('submit', function submit(event) {
  event.preventDefault();

  session.signal({
    type: 'msg',
    data: msgTxt.value
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
      msgTxt.value = '';
    }
  });
});

// listeners dos botoes com mensagem padrao
// --- INJETAR CONTRASTE
var button = document.getElementById("ic");
button.addEventListener("click", function(event){
  event.preventDefault();

  session.signal({
    type: 'msg',
    data: "injetar contraste"
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
      msgTxt.value = '';
    }
  });
});

// --- INJETAR CONTRASTE
var button = document.getElementById("pp");
button.addEventListener("click", function(event){
  event.preventDefault();

  session.signal({
    type: 'msg',
    data: "posicionar paciente"
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
      msgTxt.value = '';
    }
  });
});
}
