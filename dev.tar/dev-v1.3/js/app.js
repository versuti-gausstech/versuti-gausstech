// replace these values with those generated in your TokBox Account
var apiKey = "47173734";
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";

// token: moderator
var token_biomedico = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9MmMwODUzZWUyODU5NjVmNmQ2NWY3OGExNDJhMTVhN2FhZTE0ODc2YjpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzgxODkyNyZub25jZT0wLjc4Nzk0MDA1MzQxNDgzNTUmcm9sZT1tb2RlcmF0b3ImZXhwaXJlX3RpbWU9MTYyMDQxMDkyNyZjb25uZWN0aW9uX2RhdGE9YmlvbWVkaWNvJmluaXRpYWxfbGF5b3V0X2NsYXNzX2xpc3Q9";
//var token_biomedico1 = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9MWJkOTdlNTNiNGEwN2U5NWIwMzMyNWUwNmQ2MzQyMTAyNWZjNWI4OTpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzgwMzU2NSZyb2xlPXB1Ymxpc2hlciZub25jZT0xNjE3ODAzNTY1LjIyNTY4MjE0MDYzODQmY29ubmVjdGlvbl9kYXRhPWJpb21lZGljbzEmaW5pdGlhbF9sYXlvdXRfY2xhc3NfbGlzdD0=";
//var token_biomedico2 = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9ZDBjMWU2NzdhYTE0YzU0Yzc2MmQ0NTUxN2U2YTVlOGU2OWRlYzU4MDpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzgxMzUwMSZub25jZT0wLjM0MDkxNDA3NDMwODc4OTcmcm9sZT1wdWJsaXNoZXImZXhwaXJlX3RpbWU9MTYyMDQwNTUwMCZjb25uZWN0aW9uX2RhdGE9YmlvbWVkaWNvMiZpbml0aWFsX2xheW91dF9jbGFzc19saXN0PQ==";


var machineId = "Command Center";
// gerar codigo pra buscar ordem das maquinas na tela do biomedico (M1, M2, M3)
var enfermeira1_connection = "";

var enfermeira1_connection = "";
var enfermeira2_connection = "";
var enfermeira3_connection = "";

var subscriber_enf1 = "";
var subscriber_enf2 = "";
var subscriber_enf3 = "";

var machineId_1  = "";
var machineId_2  = "";
var machineId_3  = "";

var enfermeira_stream;

var msgTxtDestiny;

// via rest-api api.gausstech.io/rest-api/api/ordem.php?estacao_id=X
// estacao_id eh o id da estacao onde o biomedico esta assigned

console.log("gauss command.comm - v1.2 - apr/07/2021");
initializeSession();

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    // testa o nome do stream pra append no div correto
    console.log("Stream created - " + event.stream.connection.data + " ID: " + event.stream.id);

    if(event.stream.connection.data == "enfermeira-1"){
        subscriber_enf1 = session.subscribe(event.stream, 'subscriber1', {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        style: {nameDisplayMode: "on"},
        showControls: true
      }, handleError);
      machineId_1 = event.stream.name;
      document.getElementById('label_m1').innerHTML = machineId_1;
      enfermeira1_connection = event.stream.connection;
    }
    if(event.stream.connection.data == "enfermeira-2"){
        subscriber_enf2 = session.subscribe(event.stream, 'subscriber2',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      machineId_2 = event.stream.name;
      document.getElementById('label_m2').innerHTML = machineId_2;
      enfermeira2_connection = event.stream.connection;
    }

    if(event.stream.connection.data == "enfermeira-3"){
      subscriber_enf3 = session.subscribe(event.stream, 'subscriber3',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      machineId_3 = event.stream.name;
      document.getElementById('label_m3').innerHTML = machineId_3;
      enfermeira3_connection = event.stream.connection;
    }

    enfermeira_stream = event.stream.streamId;
  });


  session.on('streamDestroyed', function(event) {
    // testa o nome do stream pra append no div correto
    console.log("Stream destroyed - " + event.stream.connection.data + " ID: " + event.stream.id);
    stream_name = event.stream.connection.data;
    if(stream_name == "enfermeira-1"){
        document.getElementById('label_m1').innerHTML = 'MRI-1';
    }
    if(stream_name == "enfermeira-2"){
        document.getElementById('label_m2').innerHTML = 'MRI-2';
    }
    if(stream_name == "enfermeira-3"){
        document.getElementById('label_m3').innerHTML = 'MRI-3';
    }
  });

  // Create a publisher
  var publisherProperties = {
    insertMode: 'append',
    width: 100,
    height: 75,
    name: "teste",
    style: {nameDisplayMode: "on"},
    subscribeToAudio:true,
    showControls: true,
    videoSource: null
  };

  var publisher = OT.initPublisher("publisher", publisherProperties, handleError);
  console.log("Publisher initiated ..");
  // Connect to the session
  session.connect(token_biomedico, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
      //publisher.stream.name = "teste";
      console.log("Publisher published - " + publisher.id);


    }
  });

  //----------------------------------------------------------------------------
  // tratamento do chat-1
  //----------------------------------------------------------------------------
  // Receive a message and append it to the history
  var msgHistory = document.querySelector('#history1');

  session.on("signal", function(event) {
      console.log("Signal sent from connection " + event.from.id);

      if(event.from.id == enfermeira1_connection.connectionId){
        //msgHistory = document.querySelector('#history1');
        msgHistory = document.getElementById("history1");
        //msgTxtDestiny = document.querySelector('#msgTxt1');
        msgTxtDestiny = document.getElementById("msgTxt1");
        enfermeira_connection = enfermeira1_connection;
      }
      if(event.from.id == enfermeira2_connection.connectionId){
        msgHistory = document.querySelector('#history2');
        msgTxtDestiny = document.querySelector('#msgTxt2');
        enfermeira_connection = enfermeira2_connection;

      }
      if(event.from.id == enfermeira3_connection.connectionId){
        msgHistory = document.querySelector('#history3');
        msgTxtDestiny = document.querySelector('#msgTxt3');
      }

      var msg = document.createElement('p');
      msg.textContent = event.data;
      msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';

      msgHistory.appendChild(msg);
      msg.scrollIntoView();
  });

/*  window.addEventListener("load", function () {
    var msgTxtDestiny = document.getElementById("msgTxt1");

    mover.addEventListener("submit", function (event) {
      event.preventDefault();

      session.signal({
        type: 'msg',
        data: msgTxtDestiny.value
      }, function signalCallback(error) {
        if (error) {
          console.error('Error sending signal:', error.name, error.message);
        } else {

          msgTxtDestiny.value = '';
        }
    });
  });



  // Text chat
  var form = document.getElementById("form1");
  //var msgTxt = document.querySelector('#msgTxt1');

  // Send a signal once the user enters data in the form
  window.addEventListener('submit', function submit(event) {
    event.preventDefault();

    session.signal({
      type: 'msg',
      data: msgTxtDestiny.value
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {

        msgTxtDestiny.value = '';
      }
    });
  });*/

  // listeners dos botoes com mensagem padrao
  // --- INJETAR CONTRASTE
  var button = document.getElementById("ic1");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: "injetar contraste"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp1");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: "posicionar paciente"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- MANDAR AUDIO PARA HOST-1
  var button = document.getElementById("falar1");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
        session.signal({
          to: enfermeira1_connection,
          type: 'msg',
          data: "ouvir"
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            msgTxt.value = '';
          }
        });
    }
  });

  var button = document.getElementById("nao-falar1");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
        session.signal({
          to: enfermeira1_connection,
          type: 'msg',
          data: "nao-ouvir"
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            msgTxt.value = '';
          }
        });
      }
  });


  // --- MANDAR AUDIO PARA HOST-2
  var button = document.getElementById("falar2");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf2.id != null){
        session.signal({
          to: enfermeira2_connection,
          type: 'msg',
          data: "ouvir"
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            msgTxt.value = '';
          }
        });
    }
  });

  var button = document.getElementById("nao-falar2");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf2.id != null){
        session.signal({
          to: enfermeira2_connection,
          type: 'msg',
          data: "nao-ouvir"
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            msgTxt.value = '';
          }
        });
      }
  });

  // --- MANDAR AUDIO PARA HOST-3
  var button = document.getElementById("falar3");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf3.id != null){
        session.signal({
          to: enfermeira3_connection,
          type: 'msg',
          data: "ouvir"
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            msgTxt.value = '';
          }
        });
    }
  });

  var button = document.getElementById("nao-falar3");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf3.id != null){
        session.signal({
          to: enfermeira3_connection,
          type: 'msg',
          data: "nao-ouvir"
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            msgTxt.value = '';
          }
        });
      }
  });


  var button = document.getElementById("muteall");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
          session.signal({
            to: enfermeira1_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgTxt.value = '';
            }
          });
    }

    if(subscriber_enf2.id != null){
          session.signal({
            to: enfermeira2_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgTxt.value = '';
            }
          });
    }

    if(subscriber_enf3.id != null){
          session.signal({
            to: enfermeira3_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgTxt.value = '';
            }
          });
    }
  });


  var button = document.getElementById("broadcast");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
          session.signal({
            to: enfermeira1_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgTxt.value = '';
            }
          });
    }

    if(subscriber_enf2.id != null){
          session.signal({
            to: enfermeira2_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgTxt.value = '';
            }
          });
    }

    if(subscriber_enf3.id != null){
          session.signal({
            to: enfermeira3_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgTxt.value = '';
            }
          });
    }
  });




  var msgTxt = document.querySelector('#msgTxt2');
  var button = document.getElementById("ic2");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: "injetar contraste"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp2");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: "posicionar paciente"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  var msgTxt = document.querySelector('#msgTxt3');
  var button = document.getElementById("ic3");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: "injetar contraste"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp3");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: "posicionar paciente"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

}
