<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

?>

<html>
<head>
    <title> CETAM - Gauss Command</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="css/home-style.css" rel="stylesheet" type="text/css">
		<script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js"></script>

    <style>
            * {
              box-sizing: border-box;
            }

            /* Create three equal columns that floats next to each other */
            .column {
              float: left;
              width: 33.33%;
              padding: 10px;
              height: 300px; /* Should be removed. Only for demonstration */
            }

            /* Clear floats after the columns */
            .row:after {
              content: "";
              display: table;
              clear: both;
            }
    </style>
    <script src="https://static.opentok.com/v2/js/opentok.min.js"></script>
</head>

<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>CETAM - Gauss Command</h1>
			<a href="../profile.php"><i class="fas fa-user-circle"></i>Perfil</a>
			<a href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
		</div>
	</nav>
  <div class="row">
    <div id="videos">
					<center>
					<center><button id="startSession" title="startSession" class="w3-button w3-blue w3-hover-purple"><i class="fas fa-sign-in-alt"></i> ENTRAR</button></center>
					<button id="exitSession" title="exitSession" class="w3-button w3-blue w3-hover-purple"><i class="fas fa-sign-in-alt"></i> SAIR</button>
						<br>
						<div id="publisher"></div>
						<div id="botoes_som">
								<button id="broadcast" title="Broadcast" class="w3-button w3-red w3-hover-purple"><i class="fas fa-microphone"></i> ALL</button>
								<button id="muteall" title="Mutar todos" class="w3-button w3-red w3-hover-purple"><i class="fas fa-microphone-slash"></i> ALL</button>
						</div>
				</center>
        <div class="column" style="background-color:#fff;">
					<div>
							<center><img id="paciente1" width="480" height="240" src="http://186.193.207.158:5523/stream/video/mjpeg?resolution=HD&&Username=admin&&Password=bmNjMTcwMWE=&&tempid=0.9894852465033933" alt=""></center>
					</div>
          <center>
          <h2 id="label_m1">MRI-1</h2>
					<div id="publisher1"></div>
          <div id="subscriber1"></div>
          </center>
          <div id="textchat1">
               <p id="history1"></p>
               <form id="form1">
                    <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt1"></input>
               </form><br>
							 <center>
               <button id="ic1" title="Injetar constraste" class="w3-button w3-green w3-hover-purple"><i class="fas fa-syringe"></i> IC</button>
               <button id="pp1" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple"><i class="fas fa-hospital-user"></i> PP</button>
							 <button id="fp" title="Falar com paciente" class="w3-button w3-blue w3-ripple w3-hover-blue" onmousedown="pacienteOn(1)" onmouseup="pacienteOff(1)"><i class="fas fa-procedures"></i> PAC</button>
							 <button id="fe" title="Falar com enfermagem" class="w3-button w3-blue w3-ripple w3-hover-blue"><i class="fas fa-user-nurse"></i> ENF</button>
						  </center>
          </div>
        </div>


        <div class="column" style="background-color:#fff;">
					<div>
							<center><img id="paciente2" width="480" height="240" src="" alt=""></center>
					</div>
          <center>
          <h2 id="label_m2">MRI-2</h2>
					<div id="publisher2"></div>
          <div id="subscriber2"></div>
        </center>
          <div id="textchat2">
               <p id="history2"></p>
               <form>
                    <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt2"></input>
               </form><br>
							 <center>
               <button id="ic2" title="Injetar constraste" class="w3-button w3-green w3-hover-purple"><i class="fas fa-syringe"></i> IC</button>
               <button id="pp2" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple"><i class="fas fa-hospital-user"></i> PP</button>|
							 <button id="falar2" title="Mandar audio" class="w3-button w3-blue w3-hover-purple"><i class="fas fa-microphone"></i> FALAR</button>
							 <button id="nao-falar2" title="Mutar audio" class="w3-button w3-blue w3-hover-purple"><i class="fas fa-microphone-slash"></i> MUTAR</button>
						   </center>
          </div>
        </div>
        <div class="column" style="background-color:#fff;">
					<div>
							<center><img id="paciente3" width="480" height="240" src="http://186.193.207.158:5522/stream/video/mjpeg?resolution=HD&&Username=admin&&Password=bmNjMTcwMWE=&&tempid=0.7299572934323364" alt=""></center>
					</div>
          <center>
          <h2 id="label_m3">MRI-3</h2>
          <div id="subscriber3"></div>
        </center>
          <div id="textchat3">
               <p id="history3"></p>
               <form>
                    <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt3"></input>
               </form><br>
							 <center>
               <button id="ic3" title="Injetar constraste" class="w3-button w3-green w3-hover-purple"><i class="fas fa-syringe"></i> IC</button>
               <button id="pp3" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple"><i class="fas fa-hospital-user"></i> PP</button>
							 <button id="falar3" title="Mandar audio" class="w3-button w3-blue w3-hover-purple"><i class="fas fa-microphone"></i> FALAR</button>
							 <button id="nao-falar3" title="Mutar audio" class="w3-button w3-blue w3-hover-purple"><i class="fas fa-microphone-slash"></i> MUTAR</button>
							 <button id="intercom3" title="Audio intercom" class="w3-button w3-red w3-hover-purple"><i class="fas fa-hospital-user"></i> INTERCOM</button>
						   </center>
          </div>
        </div>
    </div>

    <script type="text/javascript" src="js/app.js"></script>
  </div>


</body>
</html>
