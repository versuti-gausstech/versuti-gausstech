<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: ../index.html');
	exit;
}

$username = $_SESSION['name'];

$url_get_token = "https://api.gausstech.io/rest-api/api/token-db.php?username=" . $username;
$json = json_decode(file_get_contents($url_get_token));
$token = $json->token;

$url_get_machine = "https://api.gausstech.io/rest-api/api/machine-id.php?token=" . $token;
$json = json_decode(file_get_contents($url_get_machine));
$marca = $json->marca;
$modelo = $json->modelo;
$localizacao = $json->localizacao;

setcookie ("username", $username);
setrawcookie("token", $token);

setrawcookie("marca", $marca);
setrawcookie("modelo", $modelo);
setcookie("localizacao", $localizacao);

?>

<html>
<head>
    <title> CETAM - Gauss Command </title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="css/home-style.css" rel="stylesheet" type="text/css">
    <script src="https://static.opentok.com/v2/js/opentok.min.js"></script>
		<script src="//code.jquery.com/jquery-2.0.3.min.js" type="text/javascript" ></script>
		<script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>


</head>
<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>CETAM - Gauss Command INTERCOM</h1>
			<a href="config-intercom.php"><i class="fas fa-sign-out-alt"></i>Configurações</a>
			<a href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
		</div>
	</nav>
  <center>
    <div id="videos">
        <div id="subscriber" title="Command Center"><b>CC</b></div>
        <div id="publisher" title="Intercom"><b>Intercom</b></div>
        <!--<div id="textchatsingle" align="center">
             <p id="history"></p>
             <form>
                  <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt"></input>
             </form><br>
             <button id="ic" title="Injetar constraste" class="w3-button w3-green w3-hover-purple"><i class="fas fa-syringe"></i> IC</button>
             <button id="pp" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple"><i class="fas fa-hospital-user"></i> PP</button> |
						 <button id="fp" title="Falar com paciente" class="w3-button w3-blue w3-ripple w3-hover-blue" onmousedown="pacienteOn()" onmouseup="pacienteOff()"><i class="fas fa-procedures"></i> PAC</button>
						 <button id="fe" title="Falar com enfermagem" class="w3-button w3-blue w3-ripple w3-hover-blue" onmousedown="enfermagemOn()" onmouseup="enfermagemOff()"><i class="fas fa-user-nurse"></i> ENF</button>

        </div>-->
    <script type="text/javascript" src="js/app-intercom.js"></script>
    </div>
  </center>
</body>
</html>
