<?php
// pagina de acesso ao tecnico cryoservice
// busca os operadores, mostra na tela e da opcao de designar maquinas e criar
// estacoes de trabalho (1 estacao com ate 3 maquinas)
// marcio versuti - gausstech.io apr-03-2021

session_start();

//error_reporting(E_ALL);
error_reporting(0); 

ini_set('display_errors', 'On');

// se o usuario nao estiver logado, volta pra pagina de logar
if (!isset($_SESSION['loggedin'])) {
	header('Location: ../index.html');
	exit;
}

$username = $_SESSION['name'];

$url_get_token = "http://api.gausstech.io/rest-api/api/token-db.php?username=" . $username;
$json = json_decode(file_get_contents($url_get_token));
$token = $json->token;
$session_id = $json->session_id;

$session_id = "1_MX40NzE3MzczNH5-MTYyMzE4NjUzOTExOX4rdHArekVIYXZjK1FESldHKy84dXc5Q0x-fg";
setcookie ("username", $username);
setcookie("session_id", $session_id);
setrawcookie("token", $token);
?>

<html>
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<title>CETAM - Gauss Command Center</title>
	  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/home-style.css" rel="stylesheet" type="text/css">
    <link href="css/general.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <script src="https://static.opentok.com/v2/js/opentok.min.js"></script>

    <style>
      body, html {
        background-color: #2f3947;
      }
      img {
        display: block;
        margin-left: auto;
        margin-right: auto;
      }
    </style>
  </head>

	<body class="loggedin" style="padding:0px;">
  <div class="sidenav">
    <div class="icon-bar-left" style="height:90%;">
      <a class="active" href="#"><i class="fa fa-home" style='font-size:45px;' title="Home"></i></a> 
      <a id="startSession" href="#"><i class="fa fa-play" style='font-size:45px;' title="Conectar-se"></i></a> 
      <a id="exitSession" href="#"><i class="fa fa-stop" style='font-size:45px;' title="Desconectar"></i></a> 
      <div id="botoes_som">
        <a id="broadcast" href="#"><i class="fa fa-bullhorn" style='font-size:45px;' title="Falar a todos"></i></a> 
        <a id="muteall" href="#"><i class="fa fa-microphone-slash" style='font-size:45px;' title="Mutar a todos"></i></a> 
      </div>
      <div id="publisher" title="Command Center"></div>
    </div>
    <div class="icon-bar-left" style="height:10%;">
      <a href="logout.php"><i class="fa fa-sign-out-alt" style='font-size:45px;' title="Logout"></i></a> 
    </div>
  </div>
    
    <!-- Cameras e botoes de comunicacao -->
  <div style="padding-top:50px; padding-left:50px;">
    <div class="container-fluid" style="padding-left:100px;background-color:#2f3947">
      <div class="row">
        <div class="col">
          <div class="row">
            <div class="col-1 ">
              <div class="icon-bar-left-interno" style="height:100%;width:70px;">
                <a href="#"><i class="fa fa-user" style='font-size:45px;' title="Câmera do Paciente"></i></a> 
                <a href="#"><i class="fa fa-laptop-medical" style='font-size:45px;' title="Câmera da Sala de Operação"></i></a> 
                <img class="img-fluid w-100" src="http://cetam.gausstech.io/dev/img/philips.png" title="Unidade-1"></img>
                <center><div id="subscriber1" style="padding-top:10px;"></div></center>
                <center><div id="intercom1-div" style="padding-top:10px;"></div></center>
              </div>
            </div>
            <div class="col-11" >
              <img id="paciente1" class="img-fluid w-100" style="padding-left:5px;" src="http://186.193.207.158:5523/stream/video/mjpeg?resolution=HD&&Username=admin&&Password=bmNjMTcwMWE=&&tempid=0.9894852465033933" alt="">
            </div>
          </div>
        </div>

        <div class="col">
          <div class="row">
            <div class="col-1 ">
            <div class="icon-bar-left-interno" style="height:100%;width:70px;">
              <a href="#"><i class="fa fa-user" style='font-size:45px;' title="Câmera do Paciente"></i></a> 
              <a href="#"><i class="fa fa-laptop-medical" style='font-size:45px;' title="Câmera da Sala de Operação"></i></a> 
              <img class="img-fluid w-90" src="http://cetam.gausstech.io/dev/img/philips.png" title="Unidade-3"></img>
              <center><div id="subscriber3" style="padding-top:10px;"></div></center>
              <center><div id="intercom3-div" style="padding-top:10px;"></div></center>
            </div>
            </div>
            <div class="col-md-11" >
              <img id="paciente1" class="img-fluid w-100" style="padding-left:5px;" src="http://186.193.207.158:5522/stream/video/mjpeg?resolution=HD&&Username=admin&&Password=bmNjMTcwMWE=&&tempid=0.7299572934323364" alt="">
            </div>
          </div>
        </div>        
      </div>
    </div>
  </div>

  <!-- Historico do chat com botoes para comunicacao enfermeira/paciente -->
  <div style="padding-top:5px; padding-left:50px;">
    <div class="container-fluid" style="padding-left:100px;background-color:#2f3947">
      <div class="row">
        <div class="col">
          <div class="row">
            <div class="col-1 ">
              <div class="icon-bar-left-interno" style="height:300px;width:70px;">
                <a id="ic1" href="#"><i class="fas fa-syringe" style="font-size:45px;" title="Injetar contraste"></i></a> 
                <a id="pp1" href="#"><i class="fas fa-bed" style="font-size:45px;" title="Posicionar paciente"></i></a> 
                <a id="fp" href="#"><i class="fas fa-microphone" style="font-size:45px;" title="Falar com enfermagem"></i></a> 
                <a id="fe" href="#"><i class="fas fa-headset" style="font-size:45px;" title="Falar com paciente"></i></a> 
              </div>
            </div>
            <div class="col-11" style="height:300px;">
              <div id="textchat1" class="overflow-auto" >
                <p id="history1"></p><br>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="row">
            <div class="col-1 ">
            <div class="icon-bar-left-interno" style="height:300px;width:70px;">
                <a id="ic3" href="#"><i class="fas fa-syringe" style="font-size:45px;" title="Injetar contraste"></i></a> 
                <a id="pp3" href="#"><i class="fas fa-bed" style="font-size:45px;" title="Posicionar paciente"></i></a> 
                <a id="falar3" href="#"><i class="fas fa-microphone" style="font-size:45px;" title="Falar com enfermagem"></i></a> 
                <a id="intercom3" href="#"><i class="fas fa-headset" style="font-size:45px;" title="Falar com paciente"></i></a> 
              </div>
            </div>
            <div class="col-11" style="height:300px;">
              <div id="textchat3" class="overflow-auto">
                <p id="history3"></p><br>
              </div>              
            </div>
          </div>
        </div>        
      </div>
    </div>
  </div>

  <!-- Input box do chat -->
  <div style="padding-top:5px; padding-left:50px;">
    <div class="container-fluid" style="padding-left:100px;background-color:#2f3947">
      <div class="row">
        <div class="col">
          <div class="row">
            <div class="col-1 ">
              <div class="icon-bar-left-interno" style="height:100px;width:70px;">
                <a id="ic1" href="#"><i class="fas fa-reply" style="font-size:35px;" title="Enviar mensagem"></i></a> 
              </div>
            </div>
            <div class="col-11" >
                <form><input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui .." id="msgTxt1"></input></form>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="row">
          <div class="col-1 ">
              <div class="icon-bar-left-interno" style="height:100px;width:70px;">
                <a id="ic3" href="#"><i class="fas fa-reply" style="font-size:35px;" title="Enviar mensagem"></i></a> 
              </div>
            </div>
            <div class="col-11" >
                <form><input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui .." id="msgTxt3"></input></form>
            </div>

          </div>
        </div>               
      </div>
    </div>
  </div>


    <script type="text/javascript" src="js/duascolunas.js"></script>
  </body>
</html>
