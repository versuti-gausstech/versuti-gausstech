// replace these values with those generated in your TokBox Account
var apiKey = "47173734";
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";
var token = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9MmMwODUzZWUyODU5NjVmNmQ2NWY3OGExNDJhMTVhN2FhZTE0ODc2YjpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzgxODkyNyZub25jZT0wLjc4Nzk0MDA1MzQxNDgzNTUmcm9sZT1tb2RlcmF0b3ImZXhwaXJlX3RpbWU9MTYyMDQxMDkyNyZjb25uZWN0aW9uX2RhdGE9YmlvbWVkaWNvJmluaXRpYWxfbGF5b3V0X2NsYXNzX2xpc3Q9";

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

// Cycling through microphone inputs
var audioInputs;
let currentIndex = 0;
lstAudioCC = document.getElementById("audio-cc");
lstAudioPac = document.getElementById("audio-pac");

OT.getDevices((err, devices) => {
  audioInputs = devices.filter((device) => device.kind === 'audioInput');
  audioInputs.forEach((device, i) => {
    console.log(device.label)
    var opt = document.createElement("option");
    lstAudioCC.options.add(opt);
    opt.text = device.label;
    opt.value = device.deviceId;

    var opt = document.createElement("option");
    lstAudioPac.options.add(opt);
    opt.text = device.label;
    opt.value = device.deviceId;
  });

/*  audioInputs = devices.filter((device) => device.kind === 'audioInput');
  // Find the right starting index for cycleMicrophone
  audioInputs.forEach((device, idx) => {
    console.log(device);
  });
  console.log("Trocando o device..");
  publisher.setAudioSource(audioInputs[2].deviceId);
  console.log(publisher.getAudioSource());*/
});

function salvarAudio(){
  document.cookie = "audio_cc=" + lstAudioCC.value ;
  document.cookie = "audio_pac=" + lstAudioPac.value;
  console.log("Audio salvo.");
}
