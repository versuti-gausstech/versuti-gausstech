<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

//<meta name="viewport" content="width=device-width, initial-scale=1">
?>

<html>
<head>
    <title> CETAM - Gauss Command</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="css/home-style.css" rel="stylesheet" type="text/css">

    <style>
            * {
              box-sizing: border-box;
            }

            /* Create three equal columns that floats next to each other */
            .column {
              float: left;
              width: 33.33%;
              padding: 10px;
              height: 300px; /* Should be removed. Only for demonstration */
            }

            /* Clear floats after the columns */
            .row:after {
              content: "";
              display: table;
              clear: both;
            }
    </style>
    <script src="https://static.opentok.com/v2/js/opentok.min.js"></script>
</head>

<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>CETAM - Gauss Command</h1>
			<a href="../profile.php"><i class="fas fa-user-circle"></i>Perfil</a>
			<a href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
		</div>
	</nav>
  <div class="row">
    <div id="videos">
        <center><div id="publisher"></div></center>
        <div class="column" style="background-color:#fff;">
          <center>
          <h2>MRI-1</h2>
          <div id="subscriber1"></div>
          </center>
          <div id="textchat1">
               <p id="history1"></p>
               <form id="form1">
                    <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt1"></input>
               </form><br>
               <button id="ic1" title="Injetar constraste" class="w3-button w3-green w3-hover-purple">IC</button>
               <button id="pp1" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple">PP</button>
          </div>
        </div>


        <div class="column" style="background-color:#fff;">
          <center>
          <h2>MRI-2</h2>
          <div id="subscriber2"></div>
        </center>
          <div id="textchat2">
               <p id="history2"></p>
               <form>
                    <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt2"></input>
               </form><br>
               <button id="ic2" title="Injetar constraste" class="w3-button w3-green w3-hover-purple">IC</button>
               <button id="pp2" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple">PP</button>
          </div>
        </div>
        <div class="column" style="background-color:#fff;">
          <center>
          <h2>MRI-3</h2>
          <div id="subscriber3"></div>
        </center>
          <div id="textchat3">
               <p id="history3"></p>
               <form>
                    <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt3"></input>
               </form><br>
               <button id="ic3" title="Injetar constraste" class="w3-button w3-green w3-hover-purple">IC</button>
               <button id="pp3" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple">PP</button>
          </div>
        </div>
    </div>
    <script type="text/javascript" src="js/app.js"></script>
  </div>


</body>
</html>
