// replace these values with those generated in your TokBox Account
var apiKey = "47173734";
var sessionId = "2_MX40NzE3MzczNH5-MTYxNzYzNDExNDgwNn56dXJWV1RWYUNDUzBPOFlydGpFRXlYTkZ-UH4";
var token_biomedico = "T1==cGFydG5lcl9pZD00NzE3MzczNCZzaWc9ZmIyMzlkOTk2ODdlOGQyY2IwYWNiYjEzNzJjODMxNzAyMGFjZDA1ODpzZXNzaW9uX2lkPTJfTVg0ME56RTNNemN6Tkg1LU1UWXhOell6TkRFeE5EZ3dObjU2ZFhKV1YxUldZVU5EVXpCUE9GbHlkR3BGUlhsWVRrWi1VSDQmY3JlYXRlX3RpbWU9MTYxNzczMjQ2NyZyb2xlPXB1Ymxpc2hlciZub25jZT0xNjE3NzMyNDY3LjU1MzQyNDUxNDU4MjkmY29ubmVjdGlvbl9kYXRhPWJpb21lZGljbyZpbml0aWFsX2xheW91dF9jbGFzc19saXN0PQ==";

var machineId = "Command Center";
// gerar codigo pra buscar ordem das maquinas na tela do biomedico (M1, M2, M3)
var enfermeira1_connection = "";
var enfermeira2_connection = "";
var enfermeira3_connection = "";

var msgTxtDestiny;

// via rest-api api.gausstech.io/rest-api/api/ordem.php?estacao_id=X
// estacao_id eh o id da estacao onde o biomedico esta assigned

console.log("aoa");
initializeSession();

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    // testa o nome do stream pra append no div correto
    if(event.stream.connection.data == "enfermeira-1"){
      var subscriber = session.subscribe(event.stream, 'subscriber1', {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      enfermeira1_connection = event.stream.connection;
      console.log(event.stream.hasAudio);
      console.log(event.stream.connection.connectionId);
    }
    if(event.stream.connection.data == "enfermeira-2"){
      session.subscribe(event.stream, 'subscriber2',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      enfermeira2_connection = event.stream.connection;
    }

    if(event.stream.connection.data == "enfermeira-3"){
      session.subscribe(event.stream, 'subscriber3',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      enfermeira3_connection = event.stream.connection;
    }
  });

  // Create a publisher
  var publisher = OT.initPublisher('publisher', {
    insertMode: 'append',
    width: 100,
    height: 75,
    name: machineId,
    style: {nameDisplayMode: "on", backgroundImageURI: 'https://tokbox.com/img/styleguide/tb-colors-cream.png'},
    subscribeToAudio:true,
    subscribeToVideo:false,
    showControls: true,
    videoSource: null
    }, handleError);
  // Connect to the session
  session.connect(token_biomedico, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
    }
  });

  //----------------------------------------------------------------------------
  // tratamento do chat-1
  //----------------------------------------------------------------------------
  // Receive a message and append it to the history
  var msgHistory = document.querySelector('#history1');

  session.on("signal", function(event) {
      console.log("Signal sent from connection " + event.from.id);

      if(event.from.id == enfermeira1_connection.connectionId){
        //msgHistory = document.querySelector('#history1');
        msgHistory = document.getElementById("history1");
        //msgTxtDestiny = document.querySelector('#msgTxt1');
        msgTxtDestiny = document.getElementById("msgTxt1");
      }
      if(event.from.id == enfermeira2_connection.connectionId){
        msgHistory = document.querySelector('#history2');
        msgTxtDestiny = document.querySelector('#msgTxt2');
      }
      if(event.from.id == enfermeira3_connection.connectionId){
        msgHistory = document.querySelector('#history3');
        msgTxtDestiny = document.querySelector('#msgTxt3');
      }

      var msg = document.createElement('p');
      msg.textContent = event.data;
      msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';

      msgHistory.appendChild(msg);
      msg.scrollIntoView();
  });

/*  window.addEventListener("load", function () {
    var msgTxtDestiny = document.getElementById("msgTxt1");

    mover.addEventListener("submit", function (event) {
      event.preventDefault();

      session.signal({
        type: 'msg',
        data: msgTxtDestiny.value
      }, function signalCallback(error) {
        if (error) {
          console.error('Error sending signal:', error.name, error.message);
        } else {

          msgTxtDestiny.value = '';
        }
    });
  });



  // Text chat
  var form = document.getElementById("form1");
  //var msgTxt = document.querySelector('#msgTxt1');

  // Send a signal once the user enters data in the form
  window.addEventListener('submit', function submit(event) {
    event.preventDefault();

    session.signal({
      type: 'msg',
      data: msgTxtDestiny.value
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {

        msgTxtDestiny.value = '';
      }
    });
  });*/

  // listeners dos botoes com mensagem padrao
  // --- INJETAR CONTRASTE
  var button = document.getElementById("ic1");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: "injetar contraste"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp1");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: "posicionar paciente"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });


  var msgTxt = document.querySelector('#msgTxt2');
  var button = document.getElementById("ic2");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: "injetar contraste"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp2");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: "posicionar paciente"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  var msgTxt = document.querySelector('#msgTxt3');
  var button = document.getElementById("ic3");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: "injetar contraste"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp3");
  button.addEventListener("click", function(event){
    event.preventDefault();

    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: "posicionar paciente"
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        msgTxt.value = '';
      }
    });
  });

}
