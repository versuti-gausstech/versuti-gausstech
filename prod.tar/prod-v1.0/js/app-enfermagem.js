//sempre constante
var apiKey = "47173734";

// indentifica a sala que contem o biomedico e as 3 maquinas
// relayed session
var sessionId = "1_MX40NzE3MzczNH5-MTYyMzE4NjUzOTExOX4rdHArekVIYXZjK1FESldHKy84dXc5Q0x-fg";

// variavel que pega a conexao do biomedico do gauss command
var biomedico_connection;
var command_center_user = "";
var token_enfermagem = "";

var username = readCookie('username');

token_enfermagem = readCookie('token');
var marca = readCookie('marca');
var modelo = readCookie('modelo');
var localizacao = readCookie('localizacao');

var audiodevice_cc = readCookie('audio_cc');
var audiodevice_pac = readCookie('audio_pac');
var audiodevice = "";

var machineId = modelo + " " + marca + ' @ ' + localizacao;

// (optional) add server code here
initializeSession();

function pacienteOn(){
		console.log("Falando com o paciente..");
}

function pacienteOff(){
		console.log("Nao falando com o paciente.")
}

function enfermagemOn(){
		console.log("Falando com a enfermagem..")
}

function enfermagemOff(){
		console.log("Nao falando com a enfermagem.")

}

// pega os cookies gerados na sessao para obter o usuario logado
function readCookie(name) {
	var cookiename = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++)
	{
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(cookiename) == 0) return c.substring(cookiename.length,c.length);
	}
	return null;
}

// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

var subscriber = "";
var sinkId;
function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    console.log("Novo stream criado na sessao - ID : " +event.stream.id);
    console.log("Nome do stream: " + event.stream.connection.data);
		command_center_user = event.stream.connection.data;
    if(event.stream.connection.data == "biomedico"){
      subscriber = session.subscribe(event.stream, 'subscriber', {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      biomedico_connection = event.stream.connection;
			//deviceId = "32aaf6ae33b71c376c8b0e938a87a9834b5872e9b1a131b4fc978d611a726bfa";
			subscriber.subscribeToAudio(false);
			subscriber.on('videoElementCreated', (event) => {
				console.log(session);
				/*if (typeof event.element.sinkId !== 'undefined') {

					event.element.setSinkId(deviceId)
			    .then(() => {
			      console.log('successfully set the audio output device');
			    })
			    .catch((err) => {
			      console.error('Failed to set the audio output device ', err);
			    });
			  } else {
			    console.warn('device does not support setting the audio output');
			  }*/
			});
      return event.stream.connection.data;
   }
  });

  // Create a publisher
  var publisher = OT.initPublisher('publisher', {
    insertMode: 'append',
    width: 100,
    height: 75,
    style: {nameDisplayMode: "on"},
    subscribeToAudio:true,
    showControls: true,
		name: machineId,
    videoSource: null
  }, handleError);

	console.log("Device selecionado [Command Center Audio]: " + audiodevice_cc);
	console.log("Device selecionado [Patient Audio]: " + audiodevice_pac);
	console.log("Publisher criado e inicializado... aeeeeee");

  // Connect to the session
  session.connect(token_enfermagem, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
			console.log("Publisher publicado!");
			audiodevice = audiodevice_cc;
			publisher.setAudioSource(audiodevice).then(() => console.log(publisher.getAudioSource()));
    }
  });

  // Receive a message and append it to the history
  var msgHistory = document.querySelector('#history');
  var onHistoryScreen = false;
  session.on("signal", function(event) {
      console.log("Sinal recebido da conexao (ID): " + event.from.id + " | Mensagem: " + event.data);
      if(event.from.id == biomedico_connection.connectionId){
        onHistoryScreen = true;
				//console.log(element);
				if(event.data == "ouvir"){
						subscriber.subscribeToAudio(true);
						subscriber.setAudioVolume(100);
						//audiodevice = audiodevice_cc;
						//event.element.setSinkId("7e2cb6af74b43efd07230ae86f76af104620ed0e8ddf3ab2d0b5396d8ddbd417");
						// escolhe o microfone (audioInput) da enfermagem
						//publisher.setAudioSource(audiodevice).then(() => subscriber.subscribeToAudio(true));
						console.log("Comunicacao Command Center <-> Enfermagem");
            onHistoryScreen = false;
        }
        if(event.data == "nao-ouvir"){
						subscriber.subscribeToAudio(false);
						subscriber.setAudioVolume(0);

						//audiodevice = audiodevice_cc;
						//publisher.setAudioSource(audiodevice).then(() => subscriber.subscribeToAudio(false));
						console.log("Comunicacao Command Center <-> Enfermagem");
            onHistoryScreen = false;
        }

				if(event.data == "ouvir-paciente"){
						subscriber.subscribeToAudio(false);
						audiodevice = audiodevice_pac;
						//event.element.setSinkId("cf13026e2dbf896b16b11db050731abd7d68ffcdb90e8b0ad5ca341ea6f11730");
						// escolhe o microfone (audioInput) do paciente
						publisher.setAudioSource(audiodevice).then(() => subscriber.subscribeToAudio(true));
						console.log("Comunicacao Command Center <-> Paciente");
            onHistoryScreen = false;
        }

				if(event.data == "nao-ouvir-paciente"){
						subscriber.subscribeToAudio(false);
						audiodevice = audiodevice_pac;
						publisher.setAudioSource(audiodevice).then(() => subscriber.subscribeToAudio(false));
						console.log("Comunicacao Command Center <-> Enfermagem");
            onHistoryScreen = false;
        }

				if(event.data == "intercom_on"){
						subscriber.subscribeToAudio(true);
						subscriber.setAudioVolume(100);
						console.log("Intercom ligado :" + subscriber.getAudioVolume());
            onHistoryScreen = false;
        }

				if(event.data == "intercom_off"){
						subscriber.subscribeToAudio(false);
						subscriber.setAudioVolume(0);
						console.log("Intercom desligado :" + subscriber.getAudioVolume());
            onHistoryScreen = false;
        }

				if(onHistoryScreen){
		        msgHistory = document.querySelector('#history');
		        var msg = document.createElement('p');
		        msg.textContent = command_center_user + " : " + event.data;
		        msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';
		        msgHistory.appendChild(msg);
		        msg.scrollIntoView();
				}
      }
  });


// Text chat
var form = document.querySelector('form');
var msgTxt = document.querySelector('#msgTxt');

msgTxt.addEventListener('keypress', function (e) {
		if (e.key === 'Enter') {
			e.preventDefault();
			txtMensagem = msgTxt.value ;
			msgHistory = document.querySelector('#history');

			var msg = document.createElement('p');
			msg.textContent = machineId + " : " + txtMensagem;
			msg.className = 'mine';
			msgHistory.appendChild(msg);
			msg.scrollIntoView();
			console.log("Mensagem de chat enviada: " + txtMensagem);
			session.signal({
				type: 'msg',
				data: txtMensagem
			}, function signalCallback(error) {
				if (error) {
					console.error('Error sending signal:', error.name, error.message);
				} else {
					msgTxt.value = '';
				}
			});
		}
});

// listeners dos botoes com mensagem padrao
// --- INJETAR CONTRASTE
var button = document.getElementById("ic");
button.addEventListener("click", function(event){
  event.preventDefault();
	var btnCommand = "injetar constraste";
  session.signal({
    type: 'msg',
    data: btnCommand
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
			var msg = document.createElement('p');
			// HARDCODED machineId porque a mensagem vem do operador, mudar depois para nome de usuario
			machineId = "operador";			
			msg.textContent = machineId + " : " + btnCommand;
			msg.className = 'mine';
			msgHistory.appendChild(msg);
			msg.scrollIntoView();
      msgTxt.value = '';
    }
  });
});

// --- POSICIONAR PACIENTE
var button = document.getElementById("pp");
button.addEventListener("click", function(event){
  event.preventDefault();
	var btnCommand = "posicionar paciente";
  session.signal({
    type: 'msg',
    data: btnCommand
  }, function signalCallback(error) {
    if (error) {
      console.error('Error sending signal:', error.name, error.message);
    } else {
			// HARDCODED machineId porque a mensagem vem do operador, mudar depois para nome de usuario
			machineId = "operador";
			var msg = document.createElement('p');
			msg.textContent = machineId + " : " + btnCommand;
			msg.className = 'mine';
			msgHistory.appendChild(msg);
			msg.scrollIntoView();

      msgTxt.value = '';
    }
  });
});


}
