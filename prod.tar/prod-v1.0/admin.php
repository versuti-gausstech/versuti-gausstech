<?php
// pagina de admin do sistema
// busca os operadores, mostra na tela e da opcao de designar maquinas e criar
// estacoes de trabalho (1 estacao com ate 3 maquinas)
// marcio versuti - gausstech.io apr-03-2021

// We need to use sessions, so you should always start sessions using the below code.
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 'On');

// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

$config = parse_ini_file("../webservice-php/db_config.ini");

// configuracao do server mysql
$DATABASE_HOST = $config['dbhost'];
$DATABASE_USER = $config['dbuser'];
$DATABASE_PASS = $config['dbpass'];
$DATABASE_NAME = $config['dbname'];
$project       = $config['project'];

?>

<html>
	<head>
		<meta charset="utf-8">
		<title>Gauss Command</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/home-style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    <script src="https://cdn.jsdelivr.net/npm/promise-polyfill@7/dist/polyfill.min.js" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fetch/2.0.3/fetch.min.js" charset="utf-8"></script>
    <style>
      img{
          max-width: 49.6%;
          align: center;
          display: inline-block; /* remove extra space below image */
      }
    </style>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script>
	$(document).ready(function() {
		var selected_workstation = '';
		var btnVerEstacao = document.getElementById('ver_estacao');
		var btnRemover = document.getElementById('remove_maquina');
		var select = document.getElementById('listMaquinas');


		btnVerEstacao.addEventListener("click", function(){
			var workstations = [];
			$.each($(".workstations option:selected"), function(){            
				workstations.push($(this).val());
			});
			selected_workstation =  workstations.join(", ");
		});

		var btnEditarEstacao = document.getElementById('editar_estacao');
		btnEditarEstacao.addEventListener("click", function(){
			var m1 = '';
			var m2 = '';
			var m3 = '';

			var workstations = [];
			$.each($(".workstations option:selected"), function(){            
				workstations.push($(this).val());
			});
			selected_workstation =  workstations.join(", ");

			var labelMaquinas = document.getElementById('labelMaquinas');
			labelMaquinas.innerHTML = 'Maquinas na Estacao ' + selected_workstation;

			var json_obj = JSON.parse(Get("https://api.gausstech.io/dev-api/api/estacao.php?workstation=" + selected_workstation));

			var length = select.options.length;
			for (i = length-1; i >= 0; i--) {
 				select.options[i] = null;
			}

			m1 = json_obj.m1_id;
			m2 = json_obj.m2_id;
			m3 = json_obj.m3_id;

			var json_m1 =  JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php?id=" + m1));
			var json_m2 =  JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php?id=" + m2));
			var json_m3 =  JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php?id=" + m3));

			marca_1 = json_m1.marca;
			modelo_1 = json_m1.modelo;
			local_1 = json_m1.localizacao;

			marca_2 = json_m2.marca;
			modelo_2 = json_m2.modelo;
			local_2 = json_m2.localizacao;

			marca_3 = json_m3.marca;
			modelo_3 = json_m3.modelo;
			local_3 = json_m3.localizacao;

			var opt1 = document.createElement('option');
			var opt2 = document.createElement('option');
			var opt3 = document.createElement('option');

			opt1.value = m1;
			opt1.text = 'Marca: ' + marca_1 + ' | Modelo: ' + modelo_1 + ' | Local: ' + local_1;
			select.add(opt1);

			opt2.value = m2;
			opt2.text = 'Marca: ' + marca_2 + ' | Modelo: ' + modelo_2 + ' | Local: ' + local_2;
			select.add(opt2);

			opt3.value = m3;
			opt3.text = 'Marca: ' + marca_3 + ' | Modelo: ' + modelo_3 + ' | Local: ' + local_3;
			select.add(opt3);
		});

		btnRemover.addEventListener("click", function(){
			var maquinas = [];
			$.each($(".listMaquinas option:selected"), function(){            
				maquinas.push($(this).val());
			});
			selected_machine =  parseInt(maquinas.join(", "));
			console.log('Selecionada: ' + selected_machine);
			select.remove(selected_machine - 1);
		});
	});

	function Get(yourUrl){
		var Httpreq = new XMLHttpRequest(); // a new request
		Httpreq.open("GET",yourUrl,false);
		Httpreq.send(null);
		return Httpreq.responseText;          
	}
	</script>

	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>CETAM - <?php echo "Logado como: {$_SESSION['usertype']}"; ?></h1>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Perfil</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>

		<h3>Página de administração do sistema</h3>
			<h4>Workstations</h4>
			<form>
				<select class='workstations' size='3'>  
					<option value='1'> Estação 1 </option>  
					<option value='2'> Estação 2 </option>  
					<option value='3'> Estação 3 </option>  
				</select> <br><br>		
				<button id='ver_estacao' type='button'>Ver</button>
				<button id='editar_estacao' type='button'>Editar</button>
			</form>

			<br>

			<div id='maquinas'><h4 id='labelMaquinas'>Maquinas</h4>
				<select id='listMaquinas' class='listMaquinas' size='3'>  
	
				</select> <br><br>		
				<button id='remove_maquina' type='button'>Remover</button>
				<button id='add_maquina' type='button'>Adicionar</button>
			</div>

			<br>
  </body>
</html>
