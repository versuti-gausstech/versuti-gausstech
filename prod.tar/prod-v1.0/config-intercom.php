<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: ../index.html');
	exit;
}

?>

<html>
<head>
    <title> Configuração do Intercom</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="css/home-style.css" rel="stylesheet" type="text/css">
    <script src="https://static.opentok.com/v2/js/opentok.min.js"></script>
		<script src="//code.jquery.com/jquery-2.0.3.min.js" type="text/javascript" ></script>
		<script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>


</head>
<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>CETAM - Gauss Command</h1>
      <a href="intercom.php"><i class="fas fa-sign-out-alt"></i>Home</a>
			<a href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
		</div>
	</nav>
  <?php echo "<h3> Olá, " . $_COOKIE['username'] . "!"; ?>
  <h4>Dados desse intercom:</h4>
  <ul>
  <?php
    echo "<li>Equipamento: Ressonância Magnética</li>";
    echo "<li>Marca: " . $_COOKIE['marca'] . "</li>";
    echo "<li>Modelo: " . $_COOKIE['modelo'] . "</li>";
    echo "<li>Localização: " . $_COOKIE['localizacao'] . "</li>";
  ?>
  </ul>

  <h4>Equipamentos de áudio:</h4>
  <ul>
    <li>Interface de audio : <select id="audio-cc"></select></li>
    <!--<li>Interface de audio com o Paciente: <select id="audio-pac"></select></li>-->
		<button id="editar" type="button" onclick="enable()">Editar</button>
    <button id="salvar" type="button" onclick="salvarAudio()">Salvar</button>
  </ul>
  <script type="text/javascript" src="js/devices.js"></script>
</body>
</html>
