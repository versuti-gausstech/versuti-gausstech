<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

?>

<html>
<head>
    <title> Configuração </title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="css/home-style.css" rel="stylesheet" type="text/css">
		<script src="//code.jquery.com/jquery-2.0.3.min.js" type="text/javascript" ></script>
		<script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

    <style>
* {
  box-sizing: border-box;
}

/* Create four equal columns that floats next to each other */
.column {
  float: left;
  width: 25%;
  padding: 10px;
  /*height: 300px;  Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.control-label .text-info { display:inline-block; }

</style>
</head>
<body class="loggedin">
	<nav class="navtop">
		<div>
			<h1>CETAM - Gauss Command</h1>
			<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
		</div>
	</nav>
  <div>
    <?php echo "<h3 style='padding-left:10px;'> Olá, " . $_GET['username'] . "! </h3>";

      $url_get_mri = "http://api.gausstech.io:8000/mri";
      $json_mri = json_decode(file_get_contents($url_get_mri));

      foreach ($json_mri->results as $mri){
        $url_get_robo = "http://api.gausstech.io:8000/robos/localizacao/" . $mri->localizacao;
        $json_robo = json_decode(file_get_contents($url_get_robo));
        if($json_robo->results != 0){
          $robo = $json_robo->results[0];
          $robo_ip_lan = $robo->ip_lan;
          $robo_ip_vpn = $robo->ip_vpn;
        }else{
          $robo_ip_lan = "N/A";
          $robo_ip_vpn = "N/A";
        }

        $url_get_cameras = "http://api.gausstech.io:8000/cameras/localizacao/" . $mri->localizacao;
        $json_cameras = json_decode(file_get_contents($url_get_cameras));
        if($json_cameras->results != 0){
          $cameras = $json_cameras->results[0];
          $ip_paciente_lan = $cameras->ip_camera_paciente_lan;
          $ip_paciente_wan = $cameras->ip_camera_paciente_wan;
          $ip_sala_lan = $cameras->ip_camera_sala_lan;
          $ip_sala_wan = $cameras->ip_camera_sala_wan;
        }else{
          $ip_paciente_lan = "N/A";
          $ip_paciente_wan = "N/A";
          $ip_sala_lan = "N/A";
          $ip_sala_wan = "N/A";
        }

        $url_get_kvm = "http://api.gausstech.io:8000/kvm/localizacao/" . $mri->localizacao;
        $json_kvm = json_decode(file_get_contents($url_get_kvm));
        if($json_kvm->results != 0){
          $kvm = $json_kvm->results[0];
          $kvm_ip_transmitter = $kvm->ip_kvm_recep;
          $kvm_ip_receiver = $kvm->ip_kvm_transm;
        }else{
          $kvm_ip_transmitter = "N/A";
          $kvm_ip_receiver = "N/A";
        }
        echo("<div class='row'>");
        echo("<h3 style='padding-left:10px;'>" . $mri->localizacao . "</h3>");
        echo("<div style='width:15%;' class='column'");
        echo("<a><b>EQUIPAMENTO</b></a><br>");
              echo("<b>Tipo: </b>" . $mri->tipo . "<br>");
              echo("<b>Marca: </b>" . $mri->marca . "<br>");
              echo("<b>Modelo: </b>" . $mri->modelo . "<br>");
          echo("</div>");

          echo("<div style='width:15%;' class='column'");
          echo("<a><b>ROBÔ</b></a><br>");
          echo("<b>Status: </b>" . "<br>");
              echo("<b>IP LAN: </b>" . $robo_ip_lan . "<br>");
              echo("<b>IP VPN: </b>" . $robo_ip_vpn . "<br>");
          echo("</div>");        

          echo("<div style='width:15%;' class='column'");
          echo("<a><b>CÂMERAS</b></a><br>");
            echo("<b>Paciente</b><br>");
              echo("<b>IP LAN: </b>" . $ip_paciente_lan . "<br>");
              echo("<b>IP WAN: </b>" . $ip_paciente_wan . "<br><br>");
            echo("<b>Sala de Operação</b><br>");
              echo("<b>IP LAN: </b>" . $ip_sala_lan . "<br>");
              echo("<b>IP WAN: </b>" . $ip_sala_wan . "<br>");
          echo("</div>");   
          
          echo("<div style='width:50%;' class='column'");
          echo("<a><b>KVM</b></a><br>");
              echo("<b>Status: </b>" .  "<br>");
              echo("<b>IP Transmissor: </b><input disabled type='text' value='" . $kvm_ip_transmitter . "'><br>");
              echo("<b>IP Receptor: </b><input disabled type='text' value='" . $kvm_ip_receiver . "'><br>");
          echo("</div>");           
        echo("</div>");
      }


      //$token = $json->token;
      //$session_id = $json->session_id;
      
    ?>
    </div>
  <!--
  <div class='controls'><a href='#' id='edit' class='btn'><label for='name' class='control-label'><p class='text-info'><?php //echo($kvm_ip_receiver); ?></p></label></a></div>
  -->
</body>
<script>
  $('#edit').click(function() {
 var text = $('.text-info').text();
 var input = $('<input id="attribute" type="text" value="' + text + '" />')
 $('.text-info').text('').append(input);
 input.select();

 input.blur(function() {
   var text = $('#attribute').val();
   $('#attribute').parent().text(text);
   $('#attribute').remove();
 });
});
</script>

</html>
