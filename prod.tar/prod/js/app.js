var apiKey = "47173734";
var sessionId = readCookie('session_id');

// token: moderator
var token_biomedico = readCookie('token');

// identificador da estacao do gauss command
var machineId = "Gauss Command";

var enfermeira1_connection = "";
var enfermeira2_connection = "";
var enfermeira3_connection = "";

var intercom1_connection = "";
var intercom2_connection = "";
var intercom3_connection = "";


var subscriber_enf1 = "";
var subscriber_enf2 = "";
var subscriber_enf3 = "";

var machineId_1  = "";
var machineId_2  = "";
var machineId_3  = "";

//var ip_paciente = "http://100.94.172.9:7000/"; 
var ip_paciente = "http://192.168.1.153:7000/";

// falta implementar:
// via rest-api api.gausstech.io/rest-api/api/ordem.php?estacao_id=X
// estacao_id eh o id da estacao onde o biomedico esta assigned

console.log("Plataforma Gauss Command - modulo command.comm - v1.8 - mai/05/2021");

document.getElementById("botoes_som").style.visibility = "hidden";
document.getElementById("exitSession").style.visibility = "hidden";

// pega os cookies gerados na sessao para obter o usuario logado
function readCookie(name) {
	var cookiename = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++)
	{
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(cookiename) == 0) return c.substring(cookiename.length,c.length);
	}
	return null;
}


function pacienteOn(machineId){
		console.log("Falando com o paciente..");
		fetch(ip_paciente + 'philips/on');
}

function pacienteOff(machineId){
		console.log("Nao falando com o paciente.");
		fetch(ip_paciente + 'philips/off');
}

function enfermagemOn(machineId){
		console.log("Falando com a enfermagem..");
}

function enfermagemOff(machineId){
		console.log("Nao falando com a enfermagem.");

}

var button = document.getElementById("startSession");
button.addEventListener("click", function(event){
  event.preventDefault();
  document.getElementById("botoes_som").style.visibility = "visible";
  document.getElementById("startSession").style.display = "none";
  document.getElementById("exitSession").style.visibility = "visible";
  initializeSession();
});

var btnSair = document.getElementById("exitSession");
btnSair.addEventListener("click", function(event){
  event.preventDefault();
  console.log("Saindo da sessao...");
  window.location.reload(false);
});


// Handling all of our errors here by alerting them
function handleError(error) {
  if (error) {
    alert(error.message);
  }
}

function initializeSession() {
  var session = OT.initSession(apiKey, sessionId);

  // Subscribe to a newly created stream
  session.on('streamCreated', function(event) {
    console.log("Stream criado na sessao (id) : " + event.stream.id);
    console.log("Nome do stream: " + event.stream.connection.data);


    // testa o nome do stream pra append no div correto
    if(event.stream.connection.data == "enfermeira-1"){
        subscriber_enf1 = session.subscribe(event.stream, 'subscriber1', {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        style: {nameDisplayMode: "on"},
        showControls: true
      }, handleError);
      machineId_1 = event.stream.name;
      document.getElementById('label_m1').innerHTML = machineId_1;
      
      subscriber_enf1.setStyle('backgroundImageURI','https://cetam.gausstech.io/dev/img/nurse.png');
      enfermeira1_connection = event.stream.connection;
    }

    if(event.stream.connection.data == "intercom-1"){
      subscriber_intercom1 = session.subscribe(event.stream, 'intercom1-div',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      //machineId_3 = event.stream.name;
      //document.getElementById('label_m3').innerHTML = machineId_3;
      intercom1_connection = event.stream.connection;
			subscriber_intercom1.setStyle('backgroundImageURI','https://cetam.gausstech.io/dev/img/mri.png');
    }

    if(event.stream.connection.data == "enfermeira-2"){
        subscriber_enf2 = session.subscribe(event.stream, 'subscriber2',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      machineId_2 = event.stream.name;
      document.getElementById('label_m2').innerHTML = machineId_2;

      subscriber_enf1.setStyle('backgroundImageURI','https://cetam.gausstech.io/dev/img/nurse.png');
      enfermeira2_connection = event.stream.connection;
    }

    if(event.stream.connection.data == "intercom-2"){
      subscriber_intercom2 = session.subscribe(event.stream, 'intercom2-div',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      //machineId_3 = event.stream.name;
      //document.getElementById('label_m3').innerHTML = machineId_3;
      intercom2_connection = event.stream.connection;
			subscriber_intercom2.setStyle('backgroundImageURI','https://cetam.gausstech.io/dev/img/mri.png');
    }

    if(event.stream.connection.data == "enfermeira-3"){
      subscriber_enf3 = session.subscribe(event.stream, 'subscriber3',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      machineId_3 = event.stream.name;
      document.getElementById('label_m3').innerHTML = machineId_3;

			subscriber_enf3.setStyle('backgroundImageURI','https://cetam.gausstech.io/dev/img/nurse.png');
      enfermeira3_connection = event.stream.connection;
    }

		if(event.stream.connection.data == "intercom-3"){
      subscriber_intercom3 = session.subscribe(event.stream, 'intercom3-div',  {
        insertMode: 'append',
        width: 100,
        height: 75,
        subscribeToAudio:true,
        subscribeToVideo:false,
        showControls: true
      }, handleError);
      //machineId_3 = event.stream.name;
      //document.getElementById('label_m3').innerHTML = machineId_3;
      intercom3_connection = event.stream.connection;
			subscriber_intercom3.setStyle('backgroundImageURI','https://cetam.gausstech.io/dev/img/mri.png');
    }

  });

  // listener para quando um stream eh destruido
  session.on('streamDestroyed', function(event) {
    console.log("Stream destruido (id) - " + event.stream.id);
    console.log("Nome do stream: "+ event.stream.connection.data);
    stream_name = event.stream.connection.data;

    // testa o nome do stream pra append no div correto
    if(stream_name == "enfermeira-1"){
        document.getElementById('label_m1').innerHTML = 'MRI-1';
        document.getElementById('history1').innerHTML = '';
    }
    if(stream_name == "enfermeira-2"){
        document.getElementById('label_m2').innerHTML = 'MRI-2';
        document.getElementById('history2').innerHTML = '';
    }
    if(stream_name == "enfermeira-3"){
        document.getElementById('label_m3').innerHTML = 'MRI-3';
        document.getElementById('history3').innerHTML = '';
    }
  });

  // Cria um publisher
  var publisherProperties = {
    insertMode: 'append',
    width: 100,
    height: 75,
    style: {nameDisplayMode: "on"},
    subscribeToAudio:true,
    showControls: true,
    videoSource: null
  };

  var publisher = OT.initPublisher("publisher", publisherProperties, handleError);
  console.log("Publisher inicializado ..");
  // Connect to the session
  session.connect(token_biomedico, function(error) {
    // If the connection is successful, publish to the session
    if (error) {
      handleError(error);
    } else {
      session.publish(publisher, handleError);
      //publisher.stream.name = "teste";
      console.log("Publisher publicado! ");
    }
  });

  //----------------------------------------------------------------------------
  // tratamento do chat-1
  //----------------------------------------------------------------------------
  var msgHistory = document.querySelector('#history1');

  // trata a chegada de um sinal
  session.on("signal", function(event) {
      console.log("Sinal recebido da conexao (ID): " + event.from.id + " Mensagem: " + event.data);
      if(event.from.id == enfermeira1_connection.connectionId){
        //msgHistory = document.querySelector('#history1');
        msgHistory = document.getElementById("history1");
        enfermeira_connection = enfermeira1_connection;
        machineId = machineId_1;
      }
      if(event.from.id == enfermeira2_connection.connectionId){
        msgHistory = document.querySelector('#history2');
        enfermeira_connection = enfermeira2_connection;
        machineId = machineId_2;
      }
      if(event.from.id == enfermeira3_connection.connectionId){
        msgHistory = document.querySelector('#history3');
        enfermeira_connection = enfermeira3_connection;
        machineId = machineId_3;
      }

      // formata a mensagem que sera incluida no msgHistory
      var msg = document.createElement('p');
      msg.textContent = machineId + " : " + event.data;
      msg.className = event.from.connectionId === session.connection.connectionId ? 'mine' : 'theirs';
      msgHistory.appendChild(msg);
      msg.scrollIntoView();
  });

  var button = document.getElementById("muteall");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
          session.signal({
            to: enfermeira1_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
                msgHistory = document.querySelector('#history1');
                var msg = document.createElement('p');
          			msg.className = 'theirs';
          			msg.textContent = "--- ENFERMAGEM NÃO OUVINDO ---";
                msgHistory.appendChild(msg);
          			msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf2.id != null){
          session.signal({
            to: enfermeira2_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history2');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf3.id != null){
          session.signal({
            to: enfermeira3_connection,
            type: 'msg',
            data: "nao-ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history3');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM NÃO OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }
  });


  var button = document.getElementById("broadcast");
  button.addEventListener("click", function(event){
    event.preventDefault();

    if(subscriber_enf1.id != null){
          session.signal({
            to: enfermeira1_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history1');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf2.id != null){
          session.signal({
            to: enfermeira2_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history2');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }

    if(subscriber_enf3.id != null){
          session.signal({
            to: enfermeira3_connection,
            type: 'msg',
            data: "ouvir"
          }, function signalCallback(error) {
            if (error) {
              console.error('Error sending signal:', error.name, error.message);
            } else {
              msgHistory = document.querySelector('#history3');
              var msg = document.createElement('p');
              msg.className = 'theirs';
              msg.textContent = "--- ENFERMAGEM OUVINDO ---";
              msgHistory.appendChild(msg);
              msg.scrollIntoView();
            }
          });
    }
  });

  // inicializa os input texts de cada maquina
  mensagem1 = document.querySelector('#msgTxt1');
  mensagem2 = document.querySelector('#msgTxt2');
  mensagem3 = document.querySelector('#msgTxt3');

  mensagem1.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        txtMensagem = mensagem1.value ;
        msgHistory = document.querySelector('#history1');

        var msg = document.createElement('p');
        msg.textContent = machineId + " : " + txtMensagem;
        msg.className = 'mine';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
        session.signal({
          to: enfermeira1_connection,
          type: 'msg',
          data: txtMensagem
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            mensagem1.value = '';
          }
        });
      }
  });

  mensagem2.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        txtMensagem = mensagem2.value ;
        msgHistory = document.querySelector('#history2');

        var msg = document.createElement('p');
        msg.textContent = machineId + " : " + txtMensagem;
        msg.className = 'mine';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
        session.signal({
          to: enfermeira2_connection,
          type: 'msg',
          data: txtMensagem
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            mensagem2.value = '';
          }
        });
      }
  });

  mensagem3.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        txtMensagem = mensagem3.value ;
        msgHistory = document.querySelector('#history3');

        var msg = document.createElement('p');
        msg.textContent = machineId + " : " + txtMensagem;
        msg.className = 'mine';
        msgHistory.appendChild(msg);
        msg.scrollIntoView();
        session.signal({
          to: enfermeira3_connection,
          type: 'msg',
          data: txtMensagem
        }, function signalCallback(error) {
          if (error) {
            console.error('Error sending signal:', error.name, error.message);
          } else {
            mensagem3.value = '';
          }
        });
      }
  });

  // labels para os botoes de chat
  var btnCommandIC = "injetar constraste";
  var btnCommandPP = "posicionar paciente";

  // listeners dos botoes com mensagem padrao
  // --- INJETAR CONTRASTE
  var button = document.getElementById("ic1");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history1');
    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: btnCommandIC
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandIC;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

  // --- POSICIONAR PACIENTE
  var button = document.getElementById("pp1");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history1');
    session.signal({
      to: enfermeira1_connection,
      type: 'msg',
      data: btnCommandPP
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandPP;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

	// --- MANDAR AUDIO PARA HOST-1
	var button = document.getElementById("fe");
	button.addEventListener("mousedown", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "ouvir"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- ENFERMAGEM OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
		}
	});

	// --- MUTAR AUDIO PARA HOST-1
	button.addEventListener("mouseup", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "nao-ouvir"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- ENFERMAGEM NÃO OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
			}
	});


	var button = document.getElementById("fp");
	button.addEventListener("mousedown", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "ouvir-paciente"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- PACIENTE OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
		}
	});

	// --- MUTAR AUDIO PARA HOST-1
	button.addEventListener("mouseup", function(event){
		event.preventDefault();
		msgHistory = document.querySelector('#history1');
		if(subscriber_enf1.id != null){
				session.signal({
					to: enfermeira1_connection,
					type: 'msg',
					data: "nao-ouvir-paciente"
				}, function signalCallback(error) {
					if (error) {
						console.error('Error sending signal:', error.name, error.message);
					} else {
						var msg = document.createElement('p');
						msg.className = 'theirs';
						msg.textContent = "--- PACIENTE NÃO OUVINDO ---";
						msgHistory.appendChild(msg);
						msg.scrollIntoView();
					}
				});
			}
	});

  var msgTxt = document.querySelector('#msgTxt2');
  var button = document.getElementById("ic2");

  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history2');
    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: btnCommandIC
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandIC;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp2");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history2');
    session.signal({
      to: enfermeira2_connection,
      type: 'msg',
      data: btnCommandPP
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandPP;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });



  var msgTxt = document.querySelector('#msgTxt3');
  var button = document.getElementById("ic3");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history3');
    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: btnCommandIC
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandIC;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });

  // --- INJETAR CONTRASTE
  var button = document.getElementById("pp3");
  button.addEventListener("click", function(event){
    event.preventDefault();
    msgHistory = document.querySelector('#history3');
    session.signal({
      to: enfermeira3_connection,
      type: 'msg',
      data: btnCommandPP
    }, function signalCallback(error) {
      if (error) {
        console.error('Error sending signal:', error.name, error.message);
      } else {
        var msg = document.createElement('p');
  			msg.textContent = machineId + " : " + btnCommandPP;
  			msg.className = 'mine';
  			msgHistory.appendChild(msg);
  			msg.scrollIntoView();
        msgTxt.value = '';
      }
    });
  });
 //------------------------------------------------------------------------

	var button = document.getElementById("falar3");

	button.addEventListener("mousedown", function(event){
		event.preventDefault();
		console.log("falando com enfermagem");
		session.signal({
			to: enfermeira3_connection,
			type: 'msg',
			data: "ouvir"
		}, function signalCallback(error) {
			if (error) {
				console.error('Error sending signal:', error.name, error.message);
			}
		});
	});

	button.addEventListener("mouseup", function(event){
		event.preventDefault();

		console.log("enfermagem nao ouve");
		session.signal({
			to: enfermeira3_connection,
			type: 'msg',
			data: "nao-ouvir"
		}, function signalCallback(error) {
			if (error) {
				console.error('Error sending signal:', error.name, error.message);
			}
		});
	});





	var button = document.getElementById("intercom3");
	//var ip_paciente = "http://100.94.172.9:7000/";

	button.addEventListener("mousedown", function(event){
		event.preventDefault();
//		msgHistory = document.querySelector('#history2');
		fetch(ip_paciente + 'philips/on');
    
		console.log("intercom on");
		session.signal({
			to: intercom3_connection,
			type: 'msg',
			data: "intercom_on"
		}, function signalCallback(error) {
			if (error) {
        console.error('Error sending signal:', error.name, error.message);
      }
		});
	});

	button.addEventListener("mouseup", function(event){
		event.preventDefault();
//		msgHistory = document.querySelector('#history2');
		fetch(ip_paciente + 'philips/off');
		console.log("intercom off");
		session.signal({
			to: intercom3_connection,
			type: 'msg',
			data: "intercom_off"
		}, function signalCallback(error) {
			if (error) {
        console.error('Error sending signal:', error.name, error.message);
      }
		});
	});

}
