<?php
// pagina de acesso ao tecnico cryoservice
// busca os operadores, mostra na tela e da opcao de designar maquinas e criar
// estacoes de trabalho (1 estacao com ate 3 maquinas)
// marcio versuti - gausstech.io apr-03-2021

session_start();

//error_reporting(E_ALL);
error_reporting(0); 

ini_set('display_errors', 'On');

// se o usuario nao estiver logado, volta pra pagina de logar
if (!isset($_SESSION['loggedin'])) {
	header('Location: ../index.html');
	exit;
}
?>

<html>
	<head>
		<meta charset="utf-8">
		<title>CETAM - Gauss Command Center</title>
	  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/home-style.css" rel="stylesheet" type="text/css">
    <link href="css/general.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
    <style>
      * {
        box-sizing: border-box;
      }

      /* Create three equal columns that floats next to each other */
      .column {
        float: left;
        width: 33.33%;
        padding: 10px;
        height: 150px; /* Should be removed. Only for demonstration */
      }

      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      img {
        display: block;
        margin-left: auto;
        margin-right: auto;
      }
    </style>
  </head>

	<body class="loggedin" style="padding:0px;">
		<div class="sidenav">
      <div class="icon-bar-left" style="height:90%;">
        <a class="active" href="#"><i class="fa fa-home" style='font-size:45px;' title="Home"></i></a> 
        <a id="startSession" href="#"><i class="fa fa-play" style='font-size:45px;' title="Conectar-se"></i></a> 
        <a id="exitSession" href="#"><i class="fa fa-stop" style='font-size:45px;' title="Desconectar"></i></a> 
        
        <div id="botoes_som">
          <a id="broadcast" href="#"><i class="fa fa-bullhorn" style='font-size:45px;' title="Falar a todos"></i></a> 
          <a id="muteall" href="#"><i class="fa fa-microphone-slash" style='font-size:45px;' title="Mutar a todos"></i></a> 
        </div>
        <div id="videos">
          <div id="publisher" title="Command Center"></div>
        </div>

      </div>
      <div class="icon-bar-left" style="height:10%;">
        <a href="logout.php"><i class="fa fa-sign-out-alt" style='font-size:45px;' title="Logout"></i></a> 
      </div>
		</div>

		<div style="width:90%;float:right;">
      <div style="width:50%;float:left;" class="column" style="background-color:#f0;">
        <div class="divimg">
          <div style="width:10%;float:left;padding-right:0px;" class="column" style="background-color:#f0;">
            <a href="#"><i class="fa fa-play" style='font-size:45px;float:right;' title="Conectar-se"></i></a> 
          </div>
            <img id="paciente1" src="http://186.193.207.158:5523/stream/video/mjpeg?resolution=HD&&Username=admin&&Password=bmNjMTcwMWE=&&tempid=0.9894852465033933" alt=""></center>
        </div>
        <center><h2 id="label_m1">MRI-1</h2></center>
        <center>
        <div style="width:70%;" class='parent'>
          <div class='child inline-block-child' id="subscriber1" title="Enfermagem 1"></div>
          <div class='child inline-block-child' id="intercom1-div" title="Intercom 1"></div>
          <div id="textchat1">
            <p id="history1"></p>
            <form id="form1">
              <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt1"></input>
            </form><br>
            <center>
          <button id="ic1" title="Injetar constraste" class="w3-button w3-green w3-hover-purple"><i class="fas fa-syringe"></i> IC</button>
          <button id="pp1" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple"><i class="fas fa-hospital-user"></i> PP</button>
          <button id="falar1" title="Enfermagem" class="w3-btn w3-ripple w3-blue w3-hover-purple"><i class="fas fa-microphone"></i> ENFERMAGEM</button>
          <button id="intercom1" title="Audio intercom" class="w3-btn w3-ripple w3-red w3-hover-purple"><i class="fas fa-hospital-user"></i> INTERCOM</button>
          </center>
          </div>
        </div>
        </center>
      </div>

      <div style="width:50%;" class="column" style="background-color:#fff;">
        <div>
          <img id="paciente3" src="http://186.193.207.158:5522/stream/video/mjpeg?resolution=HD&&Username=admin&&Password=bmNjMTcwMWE=&&tempid=0.7299572934323364" alt=""></center>
        </div>
        <center><h2 id="label_m3">MRI-3</h2></center>
        <center>
        <div style="width:70%;" class='parent'>
          <center>
          <div class='child inline-block-child' id="subscriber3" title="Enfermagem 3"></div>
          <div class='child inline-block-child' id="intercom3-div" title="Intercom 3"></div>
          </center>
          <div id="textchat3">
          <p id="history3"></p>
          <form>
              <input type="text" autocomplete="off" placeholder="Digite sua mensagem aqui ou use os botoes abaixo" id="msgTxt3"></input>
          </form><br>
          <center>
          <button id="ic3" title="Injetar constraste" class="w3-button w3-green w3-hover-purple"><i class="fas fa-syringe"></i> IC</button>
          <button id="pp3" title="Posicionar paciente" class="w3-button w3-green w3-hover-purple"><i class="fas fa-hospital-user"></i> PP</button>
          <button id="falar3" title="Enfermagem" class="w3-btn w3-ripple w3-blue w3-hover-purple"><i class="fas fa-microphone"></i> ENFERMAGEM</button>
          <button id="intercom3" title="Audio intercom" class="w3-btn w3-ripple w3-red w3-hover-purple"><i class="fas fa-hospital-user"></i> INTERCOM</button>
          </center>
        </div>
        </center>
        </div>
        
      </div>
    <script type="text/javascript" src="js/app.js"></script>
  </div>
    </div>
  </body>
</html>
