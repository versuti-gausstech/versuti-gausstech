<?php
// pagina de admin do sistema
// busca os operadores, mostra na tela e da opcao de designar maquinas e criar
// estacoes de trabalho (1 estacao com ate 3 maquinas)
// marcio versuti - gausstech.io apr-03-2021

// We need to use sessions, so you should always start sessions using the below code.
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 'On');

// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

$config = parse_ini_file("../webservice-php/db_config.ini");

// configuracao do server mysql
$DATABASE_HOST = $config['dbhost'];
$DATABASE_USER = $config['dbuser'];
$DATABASE_PASS = $config['dbpass'];
$DATABASE_NAME = $config['dbname'];
$project       = $config['project'];

?>

<html>
	<head>
		<meta charset="utf-8">
		<title>Gauss Command</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/home-style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    <script src="https://cdn.jsdelivr.net/npm/promise-polyfill@7/dist/polyfill.min.js" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fetch/2.0.3/fetch.min.js" charset="utf-8"></script>
    <style>
		img{
			max-width: 49.6%;
			align: center;
			display: inline-block; /* remove extra space below image */
		}
		@media screen and (min-device-width:698px) {
			div#showgrid {
				width: 698px;
				margin: auto;
			}
		}

		div.column {
			border-style: solid;
			border-width: 1px;
		}

		.row {
			width: 100%;
			margin: auto;
			align: center;

		}

		@media (min-device-width: 698px) {
			.column {
				width: 230px;
				height: 230px;
				display: inline;
				float: left;
			}
		}
		.column {
			width: 230px;
			height: 230px;
			margin: auto;
		}
    </style>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script>
	$(document).ready(function() {
		var selected_workstation = '';
		var btnVerEstacao = document.getElementById('ver_estacao');
		var btnAdicionar = document.getElementById('add_maquina');
		var btnRemover = document.getElementById('remove_maquina');
		var btnUp = document.getElementById('move_up');
		var btnDown = document.getElementById('move_down');

		var select = document.getElementById('listMaquinas');
		var selectDisponiveis = document.getElementById('listDisponiveis');


		var json_obj = JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php"));
		console.log("Total de maquinas cadastradas : " + Object.keys(json_obj.machines).length);

		for(var key in json_obj.machines){
			console.log(json_obj.machines[key].operador_id);
			var opt = document.createElement('option');
			var marca = json_obj.machines[key].marca;
			var modelo = json_obj.machines[key].modelo;
			var local = json_obj.machines[key].localizacao;
			opt.value = key;
			opt.text = modelo + ' ' + marca + ' (' + local + ')';
			
			if(parseInt(json_obj.machines[key].operador_id) != 0){
				opt.disabled = true;
			}else{
				opt.disabled = false;
			}
			selectDisponiveis.add(opt);
		}

		btnAdicionar.addEventListener("click", function(){
			var workstations = [];
			$.each($(".listDisponiveis option:selected"), function(){            
				workstations.push($(this).val());
			});
			selected_workstation =  workstations.join(", ");
			selecionada = parseInt(selected_workstation);

			var opt = document.createElement('option');
			
			opt.value = 0;
			opt.text = selectDisponiveis.options[selecionada].text;
			select.add(opt);

			if(selecionada == 1){
				console.log("Ja esta no topo");
			}else{
				atual = selecionada - 1;
				nova = atual - 1;
				var temp = select.options[nova].text;
				select.options[nova].text = select.options[atual].text;
				select.options[atual].text = temp;
				select.options[nova].selected = true;
			}
			var optionLength = $(".listMaquinas option").length;
			if(optionLength < 3){
				$("#move_up").prop("disabled", true);
				$("#move_down").prop("disabled", true);
			}else{
				$("#move_up").prop("disabled", false);
				$("#move_down").prop("disabled", false);
			}			
		});

		btnUp.addEventListener("click", function(){
			var workstations = [];
			$.each($(".listMaquinas option:selected"), function(){            
				workstations.push($(this).val());
			});
			selected_workstation =  workstations.join(", ");
			selecionada = parseInt(selected_workstation);
			if(selecionada == 1){
				console.log("Ja esta no topo");
			}else{
				atual = selecionada - 1;
				nova = atual - 1;
				var temp = select.options[nova].text;
				select.options[nova].text = select.options[atual].text;
				select.options[atual].text = temp;
				select.options[nova].selected = true;
			}
			
		});

		btnDown.addEventListener("click", function(){
			var workstations = [];
			$.each($(".listMaquinas option:selected"), function(){            
				workstations.push($(this).val());
			});
			selected_workstation =  workstations.join(", ");
			selecionada = parseInt(selected_workstation);
			console.log("Selecionada: " + selecionada);
			if(selecionada == 3){
				console.log("Ja esta embaixo");
			}else{
				atual = selecionada - 1;
				nova = atual + 1;
				var temp = select.options[nova].text;
				select.options[nova].text = select.options[atual].text;
				select.options[atual].text = temp;
				select.options[nova].selected = true;
			}
			
		});

		btnVerEstacao.addEventListener("click", function(){
			var workstations = [];
			$.each($(".workstations option:selected"), function(){            
				workstations.push($(this).val());
			});
			selected_workstation =  workstations.join(", ");
		});

		var btnEditarEstacao = document.getElementById('editar_estacao');
		btnEditarEstacao.addEventListener("click", function(){
			var m1 = '';
			var m2 = '';
			var m3 = '';

			var workstations = [];
			$.each($(".workstations option:selected"), function(){            
				workstations.push($(this).val());
			});

			selected_workstation =  workstations.join(", ");

			var json_obj = JSON.parse(Get("https://api.gausstech.io/dev-api/api/estacao.php?workstation=" + selected_workstation));

			var labelMaquinas = document.getElementById('labelMaquinas');
			var label = json_obj.label;

			if(label != null){
				labelMaquinas.innerHTML = 'Maquinas @ ' + json_obj.label;
			}else{
				labelMaquinas.innerHTML = 'Maquinas @ Estacao ' + selected_workstation;
			}

			var length = select.options.length;
			for (i = length-1; i >= 0; i--) {
 				select.options[i] = null;
			}

			m1 = json_obj.m1_id;
			m2 = json_obj.m2_id;
			m3 = json_obj.m3_id;

			var json_m1 =  JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php?id=" + m1));
			var json_m2 =  JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php?id=" + m2));
			var json_m3 =  JSON.parse(Get("https://api.gausstech.io/dev-api/api/maquina.php?id=" + m3));

			marca_1 = json_m1.marca;
			modelo_1 = json_m1.modelo;
			local_1 = json_m1.localizacao;

			marca_2 = json_m2.marca;
			modelo_2 = json_m2.modelo;
			local_2 = json_m2.localizacao;

			marca_3 = json_m3.marca;
			modelo_3 = json_m3.modelo;
			local_3 = json_m3.localizacao;

			var opt1 = document.createElement('option');
			var opt2 = document.createElement('option');
			var opt3 = document.createElement('option');

			opt1.value = m1;
			opt1.text = modelo_1 + ' ' + marca_1 + ' (' + local_1 + ')';
			select.add(opt1);

			opt2.value = m2;
			opt2.text = modelo_2 + ' ' + marca_2 + ' (' + local_2 + ')';
			select.add(opt2);

			opt3.value = m3;
			opt3.text = modelo_3 + ' ' + marca_3 + ' (' + local_3 + ')';
			select.add(opt3);
			$("#add_maquina").prop("disabled",true);
		});

		btnRemover.addEventListener("click", function(){
			var maquinas = [];
			$.each($(".listMaquinas option:selected"), function(){            
				maquinas.push($(this).val());
			});
			selected_machine =  parseInt(maquinas.join(", "));
		
			var optionLength = $(".listMaquinas option").length;

			if(optionLength > 0){
				var removido = $("#listMaquinas option:selected").prop("text");
				$("#listMaquinas option:selected").remove();
				console.log("Removido: " + removido);
				$("#add_maquina").prop("disabled",false);
			}else{
				console.log("Impossivel apagar");
			}
			var optionLength = $(".listMaquinas option").length;
			if(optionLength < 3){
				$("#move_up").prop("disabled", true);
				$("#move_down").prop("disabled", true);
			}else{
				$("#move_up").prop("disabled", false);
				$("#move_down").prop("disabled", false);
			}
			Array.from(document.querySelector("#listDisponiveis").options).forEach(function(option_element) {
				let option_text = option_element.text;
				let option_value = option_element.value;

				if(removido == option_text){
					option_element.disabled = false;
				}
			});
			
		});
	});

	function Get(yourUrl){
		var Httpreq = new XMLHttpRequest(); 
		Httpreq.open("GET",yourUrl,false);
		Httpreq.send(null);
		return Httpreq.responseText;          
	}
	</script>

	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>CETAM - <?php echo "Logado como: {$_SESSION['usertype']}"; ?></h1>
				<a href="admin.php"><i class="fas fa-home"></i>Home</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>

		<h3>Estações de Trabalho</h3>
		<div class="row" id='workstationsDiv'><h4>Workstations Disponiveis</h4>
			<form>
				<select class='workstations' size='3'>  
					<option value='1'> Estação 1 ---</option>  
					<option value='2'> Estação 2 ---</option>  
					<option value='3'> Estação 3 ---</option>  
				</select> <br><br>		
				<button id='ver_estacao' type='button'>Ver</button>
				<button id='editar_estacao' type='button'>Editar</button>
				<button id='criar_estacao' type='button'>Criar</button>
			</form>
		</div>
		<div class="row" id='divDisponiveis'><h4 id='disponiveis'>Maquinas disponiveis</h4>
			<select style="max-width:200px;" id='listDisponiveis' class='listDisponiveis' size='5'>  
	
			</select> <br><br>		
			<button id='add_maquina' type='button'>Adicionar</button>

		</div>
		<div class="row" id='maquinas'><h4 id='labelMaquinas'>Maquinas</h4>
			<select id='listMaquinas' class='listMaquinas' size='3'>  
			</select> <br><br>		
			<button id='remove_maquina' type='button'>Remover</button>
			<button id='move_up' type='button'>up</button>
			<button id='move_down' type='button'>down</button>
		</div>
	</body>
</html>
