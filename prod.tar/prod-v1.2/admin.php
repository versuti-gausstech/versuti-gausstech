<?php
// pagina de admin do sistema
// busca os operadores, mostra na tela e da opcao de designar maquinas e criar
// estacoes de trabalho (1 estacao com ate 3 maquinas)
// marcio versuti - gausstech.io apr-03-2021

// We need to use sessions, so you should always start sessions using the below code.
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 'On');

// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

$config = parse_ini_file("../webservice-php/db_config.ini");

// configuracao do server mysql
$DATABASE_HOST = $config['dbhost'];
$DATABASE_USER = $config['dbuser'];
$DATABASE_PASS = $config['dbpass'];
$DATABASE_NAME = $config['dbname'];
$project       = $config['project'];

?>

<html>
	<head>
		<meta charset="utf-8">
		<title>Gauss Command</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/home-style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    <script src="https://cdn.jsdelivr.net/npm/promise-polyfill@7/dist/polyfill.min.js" charset="utf-8"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fetch/2.0.3/fetch.min.js" charset="utf-8"></script>
	</head>

	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>CETAM - <?php echo "Logado como: {$_SESSION['usertype']}"; ?></h1>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Perfil</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>

		<h3>Página de administração do sistema</h3>
		<div>
			Estações de trabalho: <a href='workstation.php'>configurar</a><br>
			Usuários: <a href='create_user.php'>criar</a> | <a href='edit_user.php'>editar</a> | <a href='delete_user.php'>apagar</a><br>
			Áudio: <a href='token.php'>tokens</a> | <a href='config_audio.php'>configurar</a>
		</div>
	</body>
</html>
